// Hand-written mirrors of the Pydantic models in backend/models/schemas.py.
// Nothing infers across the Python boundary — keep both sides in sync in one edit.

export type IbStatus = "PENDING" | "APPROVED" | "REJECTED";
export type LicenseStatus = "NONE" | "PENDING" | "ACTIVE" | "SUSPENDED" | "REVOKED" | "EXPIRED";
export type Role = "customer" | "admin";

export interface SessionIdentity {
  role: Role;
  id: string | null;
  full_name: string | null;
  email: string | null;
  username: string | null;
}

export interface RegistrationRequest {
  full_name: string;
  email: string;
  phone: string;
  mt5_account: string;
  broker: string;
  mt5_server: string;
  password: string;
}

export interface RegisterResponse {
  ok: boolean;
  status: string;
  user_id: string;
}

export interface LicenseRecord {
  id: string;
  license_id: string;
  user_id: string;
  email: string;
  mt5_account: string;
  broker: string;
  mt5_server: string;
  status: LicenseStatus;
  activation_date: string | null;
  expiry_date: string | null;
  ea_version: string;
  created_at: string;
}

export interface UserRow {
  id: string;
  full_name: string;
  email: string;
  phone: string;
  mt5_account: string;
  broker: string;
  mt5_server: string;
  ib_status: IbStatus;
  license_status: LicenseStatus;
  license_id: string | null;
  activation_date: string | null;
  expiry_date: string | null;
  ea_version: string | null;
  created_at: string;
}

export interface CustomerDetail {
  user: UserRow;
  license: LicenseRecord | null;
}

export interface AuditLogEntry {
  id: string;
  actor: string;
  action: string;
  target_email: string | null;
  details: string;
  created_at: string;
}

export interface OrderRow {
  id: string;
  order_id: string;
  user_email: string | null;
  order_type: string;
  description: string;
  created_at: string;
}

export interface UserDetail {
  user: UserRow;
  license: LicenseRecord | null;
  logs: AuditLogEntry[];
}

export interface ActionResponse {
  ok: boolean;
  user: UserRow;
}

export interface PlatformSettings {
  ea_version: string;
  license_validity_months: number;
  session_ttl_hours: number;
}

export interface AdminStats {
  total_users: number;
  pending_applications: number;
  active_licenses: number;
  revoked_licenses: number;
  total_licenses: number;
  orders: number;
  settings: PlatformSettings;
}

export interface EaInfo {
  ea_version: string;
  file_size_bytes: number;
  sha256: string;
  updated_at: string;
}

export interface LicenseCheckResponse {
  allowed: boolean;
  reason: string;
  license_id: string | null;
  status: string | null;
  expiry_date: string | null;
}

export interface MarketStatusResponse {
  server_time_utc: string;
  market_open: boolean;
  next_event: string;
}
