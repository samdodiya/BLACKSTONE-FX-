import { ApiError } from "./api";

// FastAPI reports validation failures as 422 {detail: [...]} and business errors as
// {detail: "string"} — flatten either shape into one human-readable line.
export function errorDetail(err: unknown, fallback = "Something went wrong. Please try again."): string {
  if (err instanceof ApiError) {
    const detail = (err.body as { detail?: unknown } | null)?.detail;
    if (typeof detail === "string") return detail;
    if (Array.isArray(detail)) {
      const first = detail[0] as { msg?: string } | undefined;
      if (first?.msg) return first.msg;
    }
    if (err.status === 401) return "Invalid credentials.";
    if (err.status === 403) return "Access denied.";
    if (err.status === 429) return "Too many requests — please slow down.";
  }
  return fallback;
}
