import { Link } from "react-router-dom";
import { buttonVariants } from "@/components/ui/button";
import { LogoMark } from "@/components/Logo";

export default function NotFound() {
  return (
    <div className="flex min-h-svh flex-col items-center justify-center bg-[#0B0D11] px-6 text-center text-[#F3F4F6]" data-testid="not-found-page">
      <LogoMark className="h-14 w-14" />
      <p className="mt-6 font-mono text-[11px] uppercase tracking-[0.28em] text-[#D4AF37]">404 · SIGNAL LOST</p>
      <h1 className="mt-4 font-heading text-3xl font-bold tracking-tight text-white">This route doesn't exist</h1>
      <p className="mt-3 max-w-md text-sm leading-relaxed text-[#9CA3AF]">
        The page you requested is not part of the BLACKSTONE FX system. Return to the terminal.
      </p>
      <Link to="/" className={`${buttonVariants()} mt-8`} data-testid="not-found-home-link">
        BACK TO SYSTEM
      </Link>
    </div>
  );
}
