import { Link } from "react-router-dom";
import { AlertTriangle, ShieldCheck } from "lucide-react";
import { Reveal } from "@/components/Reveal";

const SECTIONS = [
  {
    title: "1. Trading involves substantial risk",
    body: "Trading financial markets — including but not limited to foreign exchange, metals and index CFDs — involves substantial risk of loss and is not suitable for every investor. Leverage can work against you as easily as for you.",
  },
  {
    title: "2. No performance guarantee",
    body: "Past performance does not guarantee future results. BLACKSTONE FX does not guarantee profits. Automated systems, including the BLACKSTONE EA, can incur losses as well as gains, and may behave differently in live conditions than in any historical or simulated context.",
  },
  {
    title: "3. Automation is not supervision",
    body: "The BLACKSTONE EA operates under the risk envelope you configure on your own MT5 account. You remain fully responsible for your account settings, broker relationship, platform availability and ongoing monitoring.",
  },
  {
    title: "4. Licensing and availability",
    body: "EA access is administered manually, bound to a single MT5 account/broker/server combination, and remains subject to review, suspension, revocation and expiry. Access may be interrupted for maintenance, validation or administrative action.",
  },
  {
    title: "5. No advice",
    body: "Nothing on this platform — including charts, market information, documentation or support communications — constitutes investment advice, a solicitation, or a recommendation to buy or sell any instrument.",
  },
  {
    title: "6. Risk of loss acknowledgement",
    body: "By applying for access you acknowledge that you have read and understood this disclosure, that you trade with capital you can afford to lose, and that you seek independent advice where appropriate.",
  },
];

export default function RiskDisclosure() {
  return (
    <div className="carbon-dots mx-auto max-w-4xl px-4 py-14 sm:px-6 lg:py-20">
      <Reveal>
        <p className="font-mono text-[11px] uppercase tracking-[0.28em] text-[#D4AF37]">LEGAL</p>
        <h1 className="mt-3 font-heading text-3xl font-bold tracking-tight text-white sm:text-4xl">
          RISK DISCLOSURE
        </h1>
      </Reveal>

      <Reveal delay={0.05}>
        <div className="mt-8 rounded-lg border border-[#EF4444]/40 bg-[#2B1115] p-6" data-testid="risk-warning-banner">
          <div className="flex items-start gap-4">
            <AlertTriangle className="mt-0.5 h-6 w-6 shrink-0 text-[#F87171]" />
            <div>
              <p className="font-mono text-xs font-semibold tracking-[0.16em] text-[#F87171]">
                PROMINENT RISK WARNING
              </p>
              <p className="mt-2.5 text-sm leading-relaxed text-[#F3F4F6]">
                Trading financial markets involves substantial risk. Past performance does not guarantee future
                results. BLACKSTONE FX does not guarantee profits. Never trade with capital you cannot afford to
                lose.
              </p>
            </div>
          </div>
        </div>
      </Reveal>

      <div className="mt-10 space-y-5">
        {SECTIONS.map((section, i) => (
          <Reveal key={section.title} delay={i * 0.03}>
            <section className="rounded-lg border border-[#242B3A] bg-[#161B26] p-6" data-testid={`risk-section-${i + 1}`}>
              <h2 className="font-heading text-base font-semibold tracking-tight text-white">{section.title}</h2>
              <p className="mt-3 text-sm leading-relaxed text-[#9CA3AF]">{section.body}</p>
            </section>
          </Reveal>
        ))}
      </div>

      <Reveal delay={0.1}>
        <p className="mt-10 flex items-center justify-center gap-2 text-center font-mono text-[10px] uppercase tracking-[0.2em] text-[#6B7280]">
          <ShieldCheck className="h-4 w-4 text-[#D4AF37]" />
          BLACKSTONE FX — Automated Trading Technology
        </p>
        <p className="mt-6 text-center text-xs text-[#6B7280]">
          Questions about this disclosure? <Link to="/access" className="text-[#D4AF37] hover:text-[#F5D77F]">Contact the platform desk</Link>.
        </p>
      </Reveal>
    </div>
  );
}
