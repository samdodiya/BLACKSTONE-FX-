import { Link } from "react-router-dom";
import {
  ArrowRight,
  Bot,
  Fingerprint,
  Layers,
  MonitorSmartphone,
  RefreshCcw,
  ScanLine,
  Server,
  ShieldCheck,
  Workflow,
  Zap,
} from "lucide-react";
import { buttonVariants } from "@/components/ui/button";
import { Reveal } from "@/components/Reveal";

const PIPELINE = [
  { icon: ScanLine, label: "MARKET SIGNAL" },
  { icon: ShieldCheck, label: "RISK GATE" },
  { icon: Workflow, label: "POSITION SIZING" },
  { icon: Zap, label: "EXECUTION" },
  { icon: Layers, label: "BASKET CONTROL" },
  { icon: RefreshCcw, label: "RECOVERY MONITOR" },
];

const PILLARS = [
  {
    icon: Zap,
    title: "Advanced Execution",
    text: "Orders are issued through a structured execution layer with configurable entry logic, slippage awareness and MT5-native order management.",
  },
  {
    icon: ShieldCheck,
    title: "Risk Management",
    text: "A configurable risk envelope — exposure limits, equity guards and drawdown thresholds — is evaluated before any position is opened.",
  },
  {
    icon: Workflow,
    title: "Position Management",
    text: "Open positions are tracked as a portfolio: individual stop policies, scaling rules and exit weighting operate per position and per basket.",
  },
  {
    icon: RefreshCcw,
    title: "Recovery Mechanism",
    text: "Adverse sequences trigger a disciplined, capped recovery routine — strictly bounded by system-defined limits, never open-ended averaging.",
  },
  {
    icon: Layers,
    title: "Basket Management",
    text: "Related positions are grouped into baskets with unified risk accounting, controlled scaling and coordinated basket-level exits.",
  },
  {
    icon: MonitorSmartphone,
    title: "MT5 Compatibility",
    text: "Built natively for MetaTrader 5 (EX5). The EA attaches to approved charts and communicates with the license server over HTTPS.",
  },
  {
    icon: Fingerprint,
    title: "Account-Bound Licensing",
    text: "Each license is bound to one MT5 account number, one broker and one server. The EA validates against the server on every run cycle.",
  },
  {
    icon: Server,
    title: "Security Architecture",
    text: "Server-side authorization, rate-limited validation endpoints, audit logging and protected distribution. The MQ5 source is never distributed — customers receive only the compiled EX5.",
  },
];

export default function EaIntelligence() {
  return (
    <div className="carbon-dots">
      <section className="relative overflow-hidden border-b border-[#242B3A]">
        <div
          className="pointer-events-none absolute inset-0 bg-cover bg-center opacity-20"
          style={{ backgroundImage: "url(/engine-core.jpg)" }}
          aria-hidden="true"
        />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-[#0B0D11]/70 to-[#0B0D11]" aria-hidden="true" />
        <div className="relative mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:py-24">
          <Reveal>
            <p className="font-mono text-[11px] uppercase tracking-[0.28em] text-[#D4AF37]">SYSTEM BRIEFING</p>
            <h1 className="mt-4 font-heading text-4xl font-extrabold tracking-tight text-white sm:text-5xl">
              EA INTELLIGENCE
            </h1>
            <p className="mt-5 max-w-2xl text-base leading-relaxed text-[#9CA3AF] sm:text-lg">
              An engineering view of the BLACKSTONE EA: how execution, risk, recovery and licensing interact —
              and why every copy of the EA is bound to exactly one trading account.
            </p>
          </Reveal>
        </div>
      </section>

      {/* execution pipeline */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6" data-testid="ea-pipeline-section">
        <Reveal>
          <h2 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl">
            How the EA works — the execution pipeline
          </h2>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-[#9CA3AF]">
            Every automated cycle passes through the same six stages. No stage is skipped; the risk gate can halt
            the pipeline at any point.
          </p>
        </Reveal>
        <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
          {PIPELINE.map((node, i) => {
            const Icon = node.icon;
            return (
              <Reveal key={node.label} delay={i * 0.06} className="min-w-0">
                <div className="flex items-center gap-3 sm:flex-col sm:items-stretch sm:text-center">
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-md border border-[#D4AF37]/30 bg-[#2A2312]" data-testid={`ea-pipeline-node-${i + 1}`}>
                    <Icon className="h-5 w-5 text-[#D4AF37]" />
                  </div>
                  <div className="rounded-md border border-[#242B3A] bg-[#161B26] px-3 py-2 sm:w-full sm:border sm:bg-[#12161F] sm:py-3">
                    <p className="font-mono text-[9px] tracking-[0.16em] text-[#F5D77F] sm:text-[10px]">{node.label}</p>
                    <p className="font-mono text-[9px] tracking-[0.14em] text-[#4B5563]">STAGE {i + 1}</p>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </section>

      {/* eight pillars */}
      <section className="border-y border-[#242B3A] bg-[#0E121A] py-16" data-testid="ea-pillars-section">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <Reveal>
            <h2 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl">
              System pillars
            </h2>
          </Reveal>
          <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
            {PILLARS.map((pillar, i) => {
              const Icon = pillar.icon;
              return (
                <Reveal key={pillar.title} delay={i * 0.04}>
                  <div className="hover-gold h-full rounded-lg border border-[#242B3A] bg-[#161B26] p-6" data-testid={`ea-pillar-${pillar.title.toLowerCase().replace(/\s+/g, "-")}`}>
                    <Icon className="h-5 w-5 text-[#D4AF37]" />
                    <h3 className="mt-4 font-heading text-base font-semibold tracking-tight text-white">
                      {pillar.title}
                    </h3>
                    <p className="mt-2.5 text-sm leading-relaxed text-[#9CA3AF]">{pillar.text}</p>
                  </div>
                </Reveal>
              );
            })}
          </div>
        </div>
      </section>

      {/* licensing validation flow */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6" data-testid="ea-licensing-section">
        <Reveal>
          <h2 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl">
            Account-bound licensing
          </h2>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-[#9CA3AF]">
            On start-up and on every run cycle, the EA asks the license server one question: is this exact
            account, on this broker, on this server, authorized right now?
          </p>
        </Reveal>

        <div className="mt-10 grid items-stretch gap-4 lg:grid-cols-3">
          {[
            {
              icon: Bot,
              title: "BLACKSTONE EA (EX5)",
              lines: ["Runs inside MT5", "Sends account · broker · server", "Refuses to operate on denial"],
            },
            {
              icon: Server,
              title: "LICENSE SERVER",
              lines: ["Validates the binding", "Checks status + expiry", "Rate-limited · audit-logged"],
            },
            {
              icon: ShieldCheck,
              title: "DECISION",
              lines: ["ALLOW — license ACTIVE and binding matches", "DENY — any mismatch stops the EA", "Copied EX5 cannot operate elsewhere"],
            },
          ].map((card, i) => {
            const Icon = card.icon;
            return (
              <Reveal key={card.title} delay={i * 0.08}>
                <div className="flex h-full flex-col gap-4 rounded-lg border border-[#242B3A] bg-[#161B26] p-6" data-testid={`ea-licensing-card-${i + 1}`}>
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-md border border-[#D4AF37]/30 bg-[#2A2312]">
                      <Icon className="h-4.5 w-4.5 text-[#D4AF37]" />
                    </div>
                    <p className="font-mono text-xs font-semibold tracking-[0.16em] text-[#F5D77F]">{card.title}</p>
                  </div>
                  <ul className="space-y-2">
                    {card.lines.map((line) => (
                      <li key={line} className="flex items-start gap-2 text-sm text-[#9CA3AF]">
                        <span className="mt-1.5 inline-block h-1 w-1 shrink-0 rotate-45 bg-[#D4AF37]" />
                        {line}
                      </li>
                    ))}
                  </ul>
                </div>
              </Reveal>
            );
          })}
        </div>

        <Reveal delay={0.1}>
          <div className="mt-8 rounded-lg border border-[#F59E0B]/30 bg-[#2B210D] p-5" data-testid="ea-honesty-note">
            <p className="text-sm leading-relaxed text-[#FBBF24]">
              <span className="font-mono uppercase tracking-[0.14em]">Security note — </span>
              No compiled EX5 can be made 100% impossible to reverse engineer. Instead of relying on
              obfuscation, BLACKSTONE FX makes unauthorized copying ineffective: a copied EX5 simply cannot
              operate on an unapproved MT5 account, because the license server refuses validation.
            </p>
          </div>
        </Reveal>

        <Reveal delay={0.12}>
          <div className="mt-10 flex flex-col items-start justify-between gap-5 sm:flex-row sm:items-center">
            <p className="max-w-xl text-sm leading-relaxed text-[#6B7280]">
              Trading financial markets involves substantial risk. Automated systems can incur losses as well as
              gains. Past performance does not guarantee future results. BLACKSTONE FX does not guarantee
              profits.
            </p>
            <Link to="/access" className={buttonVariants()} data-testid="ea-intelligence-cta">
              GET ACCESS
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
