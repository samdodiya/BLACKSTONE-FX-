import { useState } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import {
  CalendarPlus,
  Download,
  FileText,
  KeyRound,
  LayoutDashboard,
  LifeBuoy,
  Lock,
  User,
} from "lucide-react";
import { apiGet } from "@/lib/api";
import { errorDetail } from "@/lib/errors";
import { endSession } from "@/lib/session";
import type { CustomerDetail } from "@/lib/types";
import { DashboardShell, type ShellNavItem } from "@/components/layout/DashboardShell";
import { StatusBadge } from "@/components/StatusBadge";
import { Button, buttonVariants } from "@/components/ui/button";
import { Toaster } from "@/components/ui/sonner";

// gold download link styled as a button (anchor is required to trigger the file download)
const buttonDownloadClass = buttonVariants({ size: "lg" });

const NAV: ShellNavItem[] = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "license", label: "My License", icon: KeyRound },
  { id: "download", label: "EA Download", icon: Download },
  { id: "account", label: "Account", icon: User },
  { id: "support", label: "Support", icon: LifeBuoy },
];

function Field({ label, value, mono = true }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="rounded-md border border-[#242B3A] bg-[#0E121A] p-4" data-testid={`portal-field-${label.toLowerCase().replace(/\s+/g, "-")}`}>
      <p className="font-mono text-[9px] uppercase tracking-[0.2em] text-[#6B7280]">{label}</p>
      <p className={`mt-1.5 break-all text-sm font-medium text-[#E6EDF3] ${mono ? "font-mono" : ""}`}>{value}</p>
    </div>
  );
}

function formatDate(iso: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? "—" : d.toLocaleDateString("en-GB", { year: "numeric", month: "short", day: "2-digit" });
}

export default function Portal() {
  const [tab, setTab] = useState("overview");
  const { data, isLoading, isError, error } = useQuery({
    queryKey: ["customer", "me"],
    queryFn: () => apiGet<CustomerDetail>("/customer/me"),
    retry: false,
  });

  const onLogout = () => {
    void endSession("/login");
  };

  if (isError) {
    return (
      <div className="flex min-h-svh items-center justify-center bg-[#0B0D11] p-6 text-[#F3F4F6]">
        <div className="max-w-md rounded-xl border border-[#D4AF37]/25 bg-[#12161F] p-8 text-center" data-testid="portal-signin-required">
          <Lock className="mx-auto h-8 w-8 text-[#D4AF37]" />
          <h1 className="mt-4 font-heading text-xl font-bold tracking-tight text-white">SESSION REQUIRED</h1>
          <p className="mt-2 text-sm leading-relaxed text-[#9CA3AF]">
            {errorDetail(error, "Your session could not be verified.")} Sign in to the Trader Portal to view your
            license.
          </p>
          <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row">
            <Link to="/login" className="w-full sm:w-auto" data-testid="portal-signin-link">
              <Button className="w-full">SIGN IN</Button>
            </Link>
            <Link to="/" className="w-full sm:w-auto" data-testid="portal-home-link">
              <Button variant="outline" className="w-full">BACK TO SYSTEM</Button>
            </Link>
          </div>
        </div>
        <Toaster />
      </div>
    );
  }

  const user = data?.user;
  const license = data?.license ?? null;
  const status = user?.license_status ?? "PENDING";
  const ibStatus = user?.ib_status ?? "PENDING";
  const isDownloadable = status === "ACTIVE";

  const bannerCopy: Record<string, string> = {
    PENDING: "WAITING FOR ADMIN APPROVAL — your application is in review.",
    ACTIVE: "License active — the BLACKSTONE EA is unlocked for your bound MT5 account.",
    SUSPENDED: "LICENSE SUSPENDED — EA validation will be denied until an administrator re-activates it.",
    REVOKED: "LICENSE REVOKED — EA access is disabled. Contact support if you believe this is an error.",
    EXPIRED: "LICENSE EXPIRED — request an extension from the platform administrator.",
    NONE: "NO LICENSE — your application was not approved. Contact support for details.",
  };

  return (
    <DashboardShell
      title="CLIENT PORTAL"
      subtitle={user ? `${user.full_name} · ${user.email}` : "Loading…"}
      items={NAV}
      active={tab}
      onNavigate={setTab}
      onLogout={onLogout}
      testPrefix="portal"
    >
      {isLoading ? (
        <div className="space-y-4" data-testid="portal-loading">
          <div className="h-28 animate-pulse rounded-lg bg-[#161B26]" />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-20 animate-pulse rounded-md bg-[#161B26]" />
            ))}
          </div>
        </div>
      ) : user ? (
        <div className="space-y-6">
          {/* status banner */}
          <div
            className={`rounded-lg border p-5 ${
              status === "ACTIVE" ? "border-[#10B981]/40 bg-[#06281E]/60" : "border-[#D4AF37]/25 bg-[#12161F]"
            }`}
            data-testid="portal-status-banner"
          >
            <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
              <div className="flex items-center gap-3">
                <div>
                  <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-[#6B7280]">BLACKSTONE FX</p>
                  <h1 className="mt-1 font-heading text-xl font-bold tracking-tight text-white">LICENSE OVERVIEW</h1>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <StatusBadge status={ibStatus} testId="portal-ib-status-badge" />
                <StatusBadge status={status} testId="portal-license-status-badge" />
              </div>
            </div>
            <p className="mt-4 text-sm leading-relaxed text-[#9CA3AF]">{bannerCopy[status]}</p>
          </div>

          {tab === "overview" && (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3" data-testid="portal-overview-panel">
              <Field label="Account Status" value={ibStatus} />
              <Field label="License Status" value={status} />
              <Field label="MT5 Account" value={user.mt5_account} />
              <Field label="Broker" value={user.broker} mono={false} />
              <Field label="Server" value={user.mt5_server} />
              <Field label="License ID" value={user.license_id ?? "—"} />
              <Field label="Activation Date" value={formatDate(user.activation_date)} />
              <Field label="Expiry Date" value={formatDate(user.expiry_date)} />
              <Field label="EA Version" value={user.ea_version ?? "—"} />
            </div>
          )}

          {tab === "license" && (
            <div className="rounded-lg border border-[#242B3A] bg-[#161B26] p-6" data-testid="portal-license-panel">
              <h2 className="font-heading text-lg font-semibold tracking-tight text-white">MY LICENSE</h2>
              {license ? (
                <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  <Field label="License ID" value={license.license_id} />
                  <Field label="Status" value={license.status} />
                  <Field label="EA Version" value={license.ea_version} />
                  <Field label="Activation Date" value={formatDate(license.activation_date)} />
                  <Field label="Expiry Date" value={formatDate(license.expiry_date)} />
                  <Field label="Issued" value={formatDate(license.created_at)} />
                </div>
              ) : (
                <p className="mt-4 text-sm text-[#9CA3AF]">
                  No license record yet — it is created when an administrator approves your application.
                </p>
              )}
              <p className="mt-5 rounded-md border border-[#D4AF37]/25 bg-[#0D1117] p-4 text-xs leading-relaxed text-[#9CA3AF]">
                Your license is bound to MT5 account <span className="font-mono text-[#F5D77F]">{user.mt5_account}</span> at{" "}
                <span className="font-mono text-[#F5D77F]">{user.broker}</span> on server{" "}
                <span className="font-mono text-[#F5D77F]">{user.mt5_server}</span>. The EA validates this binding
                with the license server on every run cycle.
              </p>
            </div>
          )}

          {tab === "download" && (
            <div className="rounded-lg border border-[#242B3A] bg-[#161B26] p-6 sm:p-8" data-testid="portal-download-panel">
              <h2 className="font-heading text-lg font-semibold tracking-tight text-white">BLACKSTONE EA — EX5</h2>
              {isDownloadable ? (
                <div className="mt-6">
                  <div className="flex flex-col items-start justify-between gap-5 rounded-lg border border-[#10B981]/30 bg-[#06281E]/50 p-6 sm:flex-row sm:items-center">
                    <div>
                      <p className="font-mono text-sm font-semibold tracking-[0.12em] text-[#34D399]">
                        Blackstone_EA.ex5 · {license?.ea_version ?? user.ea_version}
                      </p>
                      <p className="mt-1.5 text-xs leading-relaxed text-[#9CA3AF]">
                        Compiled EX5 for the bound MT5 account only. The MQ5 source is never distributed.
                      </p>
                    </div>
                    <a href="/api/ea/download" className={buttonDownloadClass} data-testid="ea-download-button">
                      <Download className="mr-2 h-4 w-4" />
                      DOWNLOAD BLACKSTONE EA
                    </a>
                  </div>
                  <ol className="mt-6 space-y-3" data-testid="portal-install-steps">
                    {[
                      "Download the EX5 file to your computer.",
                      "In MT5, open File → Open Data Folder → MQL5 → Experts and copy the file there.",
                      "Refresh the Navigator panel, then attach BLACKSTONE EA to an approved chart.",
                      "On start-up the EA contacts the license server and verifies your binding before operating.",
                    ].map((step, i) => (
                      <li key={i} className="flex gap-3 text-sm text-[#9CA3AF]">
                        <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded border border-[#D4AF37]/40 bg-[#2A2312] font-mono text-[10px] text-[#F5D77F]">
                          {i + 1}
                        </span>
                        {step}
                      </li>
                    ))}
                  </ol>
                </div>
              ) : (
                <div className="mt-6 rounded-lg border border-[#F59E0B]/30 bg-[#2B210D]/60 p-8 text-center" data-testid="portal-download-locked">
                  <Lock className="mx-auto h-8 w-8 text-[#FBBF24]" />
                  <p className="mt-4 font-mono text-sm font-semibold tracking-[0.16em] text-[#FBBF24]" data-testid="portal-download-locked-message">
                    {status === "PENDING"
                      ? "ACCESS PENDING ADMIN APPROVAL"
                      : status === "REVOKED"
                        ? "LICENSE REVOKED"
                        : status === "SUSPENDED"
                          ? "LICENSE SUSPENDED"
                          : status === "EXPIRED"
                            ? "LICENSE EXPIRED"
                            : "NO LICENSE ISSUED"}
                  </p>
                  <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-[#9CA3AF]">{bannerCopy[status]}</p>
                  <p className="mt-5 flex items-center justify-center gap-2 text-xs text-[#6B7280]">
                    <CalendarPlus className="h-3.5 w-3.5" />
                    The EX5 download unlocks automatically the moment your license is ACTIVE.
                  </p>
                </div>
              )}
            </div>
          )}

          {tab === "account" && (
            <div className="grid gap-4 sm:grid-cols-2" data-testid="portal-account-panel">
              <Field label="Full Name" value={user.full_name} mono={false} />
              <Field label="Email" value={user.email} />
              <Field label="Phone" value={user.phone} />
              <Field label="IB Status" value={ibStatus} />
              <Field label="Registered" value={formatDate(user.created_at)} />
              <Field label="Customer ID" value={user.id} />
            </div>
          )}

          {tab === "support" && (
            <div className="rounded-lg border border-[#242B3A] bg-[#161B26] p-6 sm:p-8" data-testid="portal-support-panel">
              <h2 className="font-heading text-lg font-semibold tracking-tight text-white">SUPPORT</h2>
              <p className="mt-3 text-sm leading-relaxed text-[#9CA3AF]">
                For license reviews, extensions and MT5 installation assistance, contact the platform desk with
                your license ID and registered email.
              </p>
              <div className="mt-5 grid gap-4 sm:grid-cols-2">
                <Field label="Email" value="contact@blackstonefx.example" />
                <Field label="Response Window" value="Within one business day" mono={false} />
              </div>
              <p className="mt-5 flex items-start gap-2 rounded-md border border-[#D4AF37]/25 bg-[#0D1117] p-4 text-xs leading-relaxed text-[#6B7280]">
                <FileText className="mt-0.5 h-4 w-4 shrink-0 text-[#D4AF37]" />
                Trading financial markets involves substantial risk. Past performance does not guarantee future
                results. BLACKSTONE FX does not guarantee profits.
              </p>
            </div>
          )}
        </div>
      ) : (
        <p className="text-sm text-[#9CA3AF]" data-testid="portal-empty">No customer record found.</p>
      )}
      <Toaster />
    </DashboardShell>
  );
}
