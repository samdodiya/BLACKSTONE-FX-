import { useState } from "react";
import { Link } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Ban,
  CheckCircle2,
  Download,
  Eye,
  FileCode,
  FileText,
  KeyRound,
  LayoutDashboard,
  Loader2,
  Pause,
  Play,
  ScrollText,
  Settings,
  ShoppingCart,
  Users,
} from "lucide-react";
import { toast } from "sonner";
import { apiGet, apiPost } from "@/lib/api";
import { errorDetail } from "@/lib/errors";
import { endSession } from "@/lib/session";
import type {
  ActionResponse,
  AdminStats,
  AuditLogEntry,
  EaInfo,
  LicenseRecord,
  OrderRow,
  UserDetail,
  UserRow,
} from "@/lib/types";
import { DashboardShell, type ShellNavItem } from "@/components/layout/DashboardShell";
import { StatusBadge } from "@/components/StatusBadge";
import { AnimatedNumber } from "@/components/AnimatedNumber";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { Button, buttonVariants } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Toaster } from "@/components/ui/sonner";

type AdminAction = "approve" | "reject" | "revoke" | "suspend" | "activate" | "extend";

const NAV: ShellNavItem[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "applications", label: "Applications", icon: FileText },
  { id: "customers", label: "Customers", icon: Users },
  { id: "licenses", label: "Licenses", icon: KeyRound },
  { id: "orders", label: "Orders", icon: ShoppingCart },
  { id: "ea", label: "EA Access", icon: FileCode },
  { id: "logs", label: "Audit Logs", icon: ScrollText },
  { id: "settings", label: "Settings", icon: Settings },
];

interface ConfirmState {
  id: string;
  name: string;
  action: AdminAction;
  title: string;
  description: string;
  confirmLabel: string;
  destructive: boolean;
}

function formatDate(iso: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? "—" : d.toLocaleDateString("en-GB", { year: "numeric", month: "short", day: "2-digit" });
}

function StatCard({ label, value, testId }: { label: string; value: number; testId: string }) {
  return (
    <div className="rounded-lg border border-[#242B3A] bg-[#161B26] p-5 transition-colors duration-200 hover:border-[#D4AF37]/40" data-testid={testId}>
      <p className="font-mono text-[9px] uppercase tracking-[0.2em] text-[#6B7280]">{label}</p>
      <p className="mt-2 font-heading text-3xl font-bold tracking-tight text-[#F5D77F]">
        <AnimatedNumber value={value} testId={`${testId}-value`} />
      </p>
    </div>
  );
}

function ActionsCell({ user, onAction, onView }: { user: UserRow; onAction: (s: ConfirmState) => void; onView: (id: string) => void }) {
  return (
    <div className="flex flex-wrap gap-1.5">
      <button
        onClick={() => onView(user.id)}
        className="rounded border border-[#242B3A] px-2 py-1 font-mono text-[9px] tracking-[0.12em] text-[#9CA3AF] transition-colors hover:border-[#D4AF37]/50 hover:text-[#D4AF37]"
        data-testid={`admin-view-btn-${user.id}`}
      >
        VIEW
      </button>
      {user.ib_status === "PENDING" && (
        <>
          <button
            onClick={() =>
              onAction({
                id: user.id,
                name: user.full_name,
                action: "approve",
                title: "APPROVE APPLICATION",
                description: `Approve ${user.full_name} (${user.email}) and activate an account-bound license for MT5 ${user.mt5_account} @ ${user.broker} / ${user.mt5_server}? EX5 download becomes available immediately.`,
                confirmLabel: "APPROVE",
                destructive: false,
              })
            }
            className="rounded border border-[#10B981]/40 bg-[#06281E] px-2 py-1 font-mono text-[9px] tracking-[0.12em] text-[#34D399] transition-colors hover:border-[#10B981]"
            data-testid={`admin-approve-btn-${user.id}`}
          >
            APPROVE
          </button>
          <button
            onClick={() =>
              onAction({
                id: user.id,
                name: user.full_name,
                action: "reject",
                title: "REJECT APPLICATION",
                description: `Reject the application from ${user.full_name} (${user.email})? No license will be issued.`,
                confirmLabel: "REJECT",
                destructive: true,
              })
            }
            className="rounded border border-[#EF4444]/40 bg-[#2B1115] px-2 py-1 font-mono text-[9px] tracking-[0.12em] text-[#F87171] transition-colors hover:border-[#EF4444]"
            data-testid={`admin-reject-btn-${user.id}`}
          >
            REJECT
          </button>
        </>
      )}
      {user.license_status === "ACTIVE" && (
        <>
          <button
            onClick={() =>
              onAction({
                id: user.id,
                name: user.full_name,
                action: "suspend",
                title: "SUSPEND LICENSE",
                description: `Suspend the license of ${user.full_name}? The EA will be denied at the next validation until re-activated.`,
                confirmLabel: "SUSPEND",
                destructive: true,
              })
            }
            className="rounded border border-[#F59E0B]/40 bg-[#2B1D0D] px-2 py-1 font-mono text-[9px] tracking-[0.12em] text-[#FB923C] transition-colors hover:border-[#F59E0B]"
            data-testid={`admin-suspend-btn-${user.id}`}
          >
            SUSPEND
          </button>
          <button
            onClick={() =>
              onAction({
                id: user.id,
                name: user.full_name,
                action: "revoke",
                title: "REVOKE LICENSE",
                description: `Revoke the license of ${user.full_name}? EA access will be permanently disabled pending a new approval.`,
                confirmLabel: "REVOKE",
                destructive: true,
              })
            }
            className="rounded border border-[#EF4444]/40 bg-[#2B1115] px-2 py-1 font-mono text-[9px] tracking-[0.12em] text-[#F87171] transition-colors hover:border-[#EF4444]"
            data-testid={`admin-revoke-btn-${user.id}`}
          >
            REVOKE
          </button>
        </>
      )}
      {(user.license_status === "SUSPENDED" || user.license_status === "REVOKED") && (
        <button
          onClick={() =>
            onAction({
              id: user.id,
              name: user.full_name,
              action: "activate",
              title: "RE-ACTIVATE LICENSE",
              description: `Re-activate the license of ${user.full_name}? An expired license will receive a fresh validity window.`,
              confirmLabel: "ACTIVATE",
              destructive: false,
            })
          }
          className="rounded border border-[#10B981]/40 bg-[#06281E] px-2 py-1 font-mono text-[9px] tracking-[0.12em] text-[#34D399] transition-colors hover:border-[#10B981]"
          data-testid={`admin-activate-btn-${user.id}`}
        >
          ACTIVATE
        </button>
      )}
    </div>
  );
}

export default function Admin() {
  const queryClient = useQueryClient();
  const [tab, setTab] = useState("dashboard");
  const [confirm, setConfirm] = useState<ConfirmState | null>(null);
  const [viewId, setViewId] = useState<string | null>(null);
  const [extendTarget, setExtendTarget] = useState<UserRow | null>(null);
  const [extendMonths, setExtendMonths] = useState("6");

  const stats = useQuery({ queryKey: ["admin", "stats"], queryFn: () => apiGet<AdminStats>("/admin/stats"), retry: false });
  const users = useQuery({ queryKey: ["admin", "users"], queryFn: () => apiGet<UserRow[]>("/admin/users"), retry: false });
  const licenses = useQuery({ queryKey: ["admin", "licenses"], queryFn: () => apiGet<LicenseRecord[]>("/admin/licenses"), retry: false });
  const orders = useQuery({ queryKey: ["admin", "orders"], queryFn: () => apiGet<OrderRow[]>("/admin/orders"), retry: false });
  const logs = useQuery({ queryKey: ["admin", "logs"], queryFn: () => apiGet<AuditLogEntry[]>("/admin/audit-logs"), retry: false });
  const eaInfo = useQuery({ queryKey: ["admin", "ea-info"], queryFn: () => apiGet<EaInfo>("/admin/ea-info"), retry: false });
  const detail = useQuery({
    queryKey: ["admin", "user", viewId],
    queryFn: () => apiGet<UserDetail>(`/admin/users/${viewId}`),
    enabled: viewId !== null,
  });

  const act = useMutation({
    mutationFn: (payload: { id: string; action: AdminAction; months?: number }) =>
      apiPost<ActionResponse>(
        `/admin/users/${payload.id}/${payload.action}`,
        payload.months ? { months: payload.months } : undefined,
      ),
    onSuccess: (data, vars) => {
      void queryClient.invalidateQueries({ queryKey: ["admin"] });
      toast.success(`${vars.action.toUpperCase()} confirmed — ${data.user.full_name}: license ${data.user.license_status}`);
      setConfirm(null);
    },
    onError: (err) => {
      toast.error(errorDetail(err, "Action failed."));
      setConfirm(null);
    },
  });

  const onLogout = () => {
    void endSession("/login");
  };

  if (stats.isError || users.isError) {
    return (
      <div className="flex min-h-svh items-center justify-center bg-[#0B0D11] p-6 text-[#F3F4F6]">
        <div className="max-w-md rounded-xl border border-[#D4AF37]/25 bg-[#12161F] p-8 text-center" data-testid="admin-signin-required">
          <Ban className="mx-auto h-8 w-8 text-[#D4AF37]" />
          <h1 className="mt-4 font-heading text-xl font-bold tracking-tight text-white">ADMINISTRATOR ACCESS REQUIRED</h1>
          <p className="mt-2 text-sm leading-relaxed text-[#9CA3AF]">
            {errorDetail(stats.error ?? users.error, "Your session could not be verified as an administrator.")}
          </p>
          <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row">
            <Link to="/login" className="w-full sm:w-auto" data-testid="admin-signin-link">
              <Button className="w-full">ADMIN SIGN IN</Button>
            </Link>
            <Link to="/" className="w-full sm:w-auto" data-testid="admin-home-link">
              <Button variant="outline" className="w-full">BACK TO SYSTEM</Button>
            </Link>
          </div>
        </div>
        <Toaster />
      </div>
    );
  }

  const userRows = users.data ?? [];
  const pendingRows = userRows.filter((u) => u.ib_status === "PENDING");
  const statsData = stats.data;

  return (
    <DashboardShell
      title="CONTROL CENTER"
      subtitle="BLACKSTONE FX · Administration"
      items={NAV}
      active={tab}
      onNavigate={setTab}
      onLogout={onLogout}
      testPrefix="admin"
    >
      {tab === "dashboard" && (
        <div className="space-y-6" data-testid="admin-dashboard-panel">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-[#D4AF37]">BLACKSTONE FX</p>
            <h1 className="mt-2 font-heading text-2xl font-bold tracking-tight text-white">CONTROL CENTER</h1>
          </div>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-6">
            <StatCard label="Total Users" value={statsData?.total_users ?? 0} testId="stat-total-users" />
            <StatCard label="Pending" value={statsData?.pending_applications ?? 0} testId="stat-pending" />
            <StatCard label="Active" value={statsData?.active_licenses ?? 0} testId="stat-active" />
            <StatCard label="Revoked" value={statsData?.revoked_licenses ?? 0} testId="stat-revoked" />
            <StatCard label="Licenses" value={statsData?.total_licenses ?? 0} testId="stat-licenses" />
            <StatCard label="Orders" value={statsData?.orders ?? 0} testId="stat-orders" />
          </div>

          <div className="rounded-lg border border-[#242B3A] bg-[#161B26] p-6">
            <div className="flex items-center justify-between">
              <h2 className="font-heading text-base font-semibold tracking-tight text-white">PENDING QUEUE</h2>
              <button
                onClick={() => setTab("applications")}
                className="font-mono text-[10px] uppercase tracking-[0.18em] text-[#D4AF37] hover:text-[#F5D77F]"
                data-testid="admin-goto-applications"
              >
                OPEN APPLICATIONS →
              </button>
            </div>
            <p className="mt-3 text-sm text-[#9CA3AF]">
              {pendingRows.length === 0
                ? "No applications awaiting review."
                : `${pendingRows.length} application${pendingRows.length === 1 ? "" : "s"} awaiting review.`}
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              {pendingRows.slice(0, 4).map((u) => (
                <span key={u.id} className="rounded-md border border-[#242B3A] bg-[#0E121A] px-3 py-1.5 font-mono text-[10px] tracking-[0.12em] text-[#9CA3AF]">
                  {u.email} · MT5 {u.mt5_account}
                </span>
              ))}
            </div>
          </div>

          <div className="rounded-lg border border-[#242B3A] bg-[#161B26] p-6">
            <h2 className="font-heading text-base font-semibold tracking-tight text-white">RECENT ACTIVITY</h2>
            <ul className="mt-4 space-y-2.5">
              {(logs.data ?? []).slice(0, 6).map((log) => (
                <li key={log.id} className="flex flex-wrap items-center justify-between gap-2 border-b border-[#242B3A]/60 pb-2.5 font-mono text-[11px] last:border-0">
                  <span className="text-[#6B7280]">{formatDate(log.created_at)}</span>
                  <span className="text-[#F5D77F]">{log.action}</span>
                  <span className="text-[#9CA3AF]">{log.details}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {(tab === "customers" || tab === "applications") && (
        <div className="space-y-5" data-testid={tab === "customers" ? "admin-customers-panel" : "admin-applications-panel"}>
          <h1 className="font-heading text-xl font-bold tracking-tight text-white">
            {tab === "customers" ? "CUSTOMERS" : "APPLICATIONS"}
          </h1>
          <div className="rounded-lg border border-[#242B3A] bg-[#161B26]">
            <Table data-testid="admin-users-table">
              <TableHeader>
                <TableRow className="border-[#242B3A] hover:bg-transparent">
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">USER ID</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">NAME</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">EMAIL</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">PHONE</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">MT5 ACCOUNT</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">BROKER</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">SERVER</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">IB STATUS</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">LICENSE STATUS</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">CREATED</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">EXPIRY</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">ACTIONS</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(tab === "customers" ? userRows : pendingRows).map((user) => (
                  <TableRow key={user.id} className="border-[#242B3A]">
                    <TableCell className="font-mono text-[10px] text-[#6B7280]">{user.id.slice(0, 8)}…</TableCell>
                    <TableCell className="whitespace-nowrap text-sm text-white">{user.full_name}</TableCell>
                    <TableCell className="whitespace-nowrap font-mono text-[11px] text-[#9CA3AF]">{user.email}</TableCell>
                    <TableCell className="whitespace-nowrap font-mono text-[11px] text-[#9CA3AF]">{user.phone}</TableCell>
                    <TableCell className="font-mono text-[11px] text-[#F5D77F]">{user.mt5_account}</TableCell>
                    <TableCell className="whitespace-nowrap text-sm text-[#9CA3AF]">{user.broker}</TableCell>
                    <TableCell className="whitespace-nowrap font-mono text-[11px] text-[#9CA3AF]">{user.mt5_server}</TableCell>
                    <TableCell><StatusBadge status={user.ib_status} testId={`admin-ib-status-${user.id}`} /></TableCell>
                    <TableCell><StatusBadge status={user.license_status} testId={`admin-license-status-${user.id}`} /></TableCell>
                    <TableCell className="whitespace-nowrap font-mono text-[11px] text-[#9CA3AF]">{formatDate(user.created_at)}</TableCell>
                    <TableCell className="whitespace-nowrap font-mono text-[11px] text-[#9CA3AF]">{formatDate(user.expiry_date)}</TableCell>
                    <TableCell><ActionsCell user={user} onAction={setConfirm} onView={setViewId} /></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            {(tab === "customers" ? userRows : pendingRows).length === 0 && (
              <p className="p-6 text-center text-sm text-[#6B7280]">Nothing here yet.</p>
            )}
          </div>
        </div>
      )}

      {tab === "licenses" && (
        <div className="space-y-5" data-testid="admin-licenses-panel">
          <h1 className="font-heading text-xl font-bold tracking-tight text-white">LICENSES</h1>
          <div className="rounded-lg border border-[#242B3A] bg-[#161B26]">
            <Table data-testid="admin-licenses-table">
              <TableHeader>
                <TableRow className="border-[#242B3A] hover:bg-transparent">
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">LICENSE ID</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">USER</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">MT5 ACCOUNT</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">BROKER / SERVER</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">STATUS</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">EXPIRY</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">ACTIONS</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(licenses.data ?? []).map((lic) => (
                  <TableRow key={lic.id} className="border-[#242B3A]">
                    <TableCell className="font-mono text-[11px] text-[#F5D77F]">{lic.license_id}</TableCell>
                    <TableCell className="whitespace-nowrap font-mono text-[11px] text-[#9CA3AF]">{lic.email}</TableCell>
                    <TableCell className="font-mono text-[11px] text-[#E6EDF3]">{lic.mt5_account}</TableCell>
                    <TableCell className="whitespace-nowrap font-mono text-[11px] text-[#9CA3AF]">
                      {lic.broker} / {lic.mt5_server}
                    </TableCell>
                    <TableCell><StatusBadge status={lic.status} testId={`admin-license-badge-${lic.id}`} /></TableCell>
                    <TableCell className="whitespace-nowrap font-mono text-[11px] text-[#9CA3AF]">{formatDate(lic.expiry_date)}</TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1.5">
                        <button
                          onClick={() => {
                            setExtendTarget(userRows.find((u) => u.id === lic.user_id) ?? null);
                            setExtendMonths("6");
                          }}
                          className="rounded border border-[#242B3A] px-2 py-1 font-mono text-[9px] tracking-[0.12em] text-[#9CA3AF] transition-colors hover:border-[#D4AF37]/50 hover:text-[#D4AF37]"
                          data-testid={`admin-extend-btn-${lic.id}`}
                        >
                          EXTEND
                        </button>
                        {lic.status === "ACTIVE" && (
                          <>
                            <button
                              onClick={() => {
                                const u = userRows.find((x) => x.id === lic.user_id);
                                if (u) {
                                  setConfirm({
                                    id: u.id, name: u.full_name, action: "suspend",
                                    title: "SUSPEND LICENSE",
                                    description: `Suspend license ${lic.license_id}? The EA will be denied at the next validation until re-activated.`,
                                    confirmLabel: "SUSPEND", destructive: true,
                                  });
                                }
                              }}
                              className="rounded border border-[#F59E0B]/40 bg-[#2B1D0D] px-2 py-1 font-mono text-[9px] tracking-[0.12em] text-[#FB923C]"
                              data-testid={`admin-lic-suspend-btn-${lic.id}`}
                            >
                              SUSPEND
                            </button>
                            <button
                              onClick={() => {
                                const u = userRows.find((x) => x.id === lic.user_id);
                                if (u) {
                                  setConfirm({
                                    id: u.id, name: u.full_name, action: "revoke",
                                    title: "REVOKE LICENSE",
                                    description: `Revoke license ${lic.license_id}? EA access will be permanently disabled pending a new approval.`,
                                    confirmLabel: "REVOKE", destructive: true,
                                  });
                                }
                              }}
                              className="rounded border border-[#EF4444]/40 bg-[#2B1115] px-2 py-1 font-mono text-[9px] tracking-[0.12em] text-[#F87171]"
                              data-testid={`admin-lic-revoke-btn-${lic.id}`}
                            >
                              REVOKE
                            </button>
                          </>
                        )}
                        {(lic.status === "SUSPENDED" || lic.status === "REVOKED") && (
                          <button
                            onClick={() => {
                              const u = userRows.find((x) => x.id === lic.user_id);
                              if (u) {
                                setConfirm({
                                  id: u.id, name: u.full_name, action: "activate",
                                  title: "RE-ACTIVATE LICENSE",
                                  description: `Re-activate license ${lic.license_id}? An expired license receives a fresh validity window.`,
                                  confirmLabel: "ACTIVATE", destructive: false,
                                });
                              }
                            }}
                            className="rounded border border-[#10B981]/40 bg-[#06281E] px-2 py-1 font-mono text-[9px] tracking-[0.12em] text-[#34D399]"
                            data-testid={`admin-lic-activate-btn-${lic.id}`}
                          >
                            ACTIVATE
                          </button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            {(licenses.data ?? []).length === 0 && <p className="p-6 text-center text-sm text-[#6B7280]">No licenses issued yet.</p>}
          </div>
        </div>
      )}

      {tab === "orders" && (
        <div className="space-y-5" data-testid="admin-orders-panel">
          <h1 className="font-heading text-xl font-bold tracking-tight text-white">ORDERS</h1>
          <div className="rounded-lg border border-[#242B3A] bg-[#161B26]">
            <Table data-testid="admin-orders-table">
              <TableHeader>
                <TableRow className="border-[#242B3A] hover:bg-transparent">
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">ORDER ID</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">USER</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">TYPE</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">DESCRIPTION</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">DATE</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(orders.data ?? []).map((order) => (
                  <TableRow key={order.id} className="border-[#242B3A]">
                    <TableCell className="font-mono text-[11px] text-[#F5D77F]">{order.order_id}</TableCell>
                    <TableCell className="whitespace-nowrap font-mono text-[11px] text-[#9CA3AF]">{order.user_email}</TableCell>
                    <TableCell className="font-mono text-[10px] tracking-[0.1em] text-[#9CA3AF]">{order.order_type}</TableCell>
                    <TableCell className="text-sm text-[#C7CCD6]">{order.description}</TableCell>
                    <TableCell className="whitespace-nowrap font-mono text-[11px] text-[#6B7280]">{formatDate(order.created_at)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            {(orders.data ?? []).length === 0 && <p className="p-6 text-center text-sm text-[#6B7280]">No orders recorded.</p>}
          </div>
        </div>
      )}

      {tab === "ea" && (
        <div className="max-w-3xl space-y-5" data-testid="admin-ea-panel">
          <h1 className="font-heading text-xl font-bold tracking-tight text-white">EA ACCESS</h1>
          <div className="rounded-lg border border-[#D4AF37]/25 bg-[#161B26] p-6">
            <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-center">
              <div>
                <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-[#6B7280]">DISTRIBUTION ARTIFACT</p>
                <p className="mt-2 font-mono text-lg font-semibold text-[#F5D77F]">Blackstone_EA.ex5 · {eaInfo.data?.ea_version ?? "—"}</p>
              </div>
              <a href="/api/ea/download" className={buttonVariants({ variant: "outline", size: "sm" })} data-testid="admin-ea-download-button">
                <Download className="mr-2 h-4 w-4" />
                DOWNLOAD ARTIFACT
              </a>
            </div>
            <dl className="mt-5 space-y-2.5 text-sm">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#242B3A]/60 pb-2.5">
                <dt className="font-mono text-[10px] tracking-[0.16em] text-[#6B7280]">SHA-256</dt>
                <dd className="break-all text-right font-mono text-[11px] text-[#E6EDF3]">{eaInfo.data?.sha256 ?? "—"}</dd>
              </div>
              <div className="flex items-center justify-between gap-2 border-b border-[#242B3A]/60 pb-2.5">
                <dt className="font-mono text-[10px] tracking-[0.16em] text-[#6B7280]">SIZE</dt>
                <dd className="font-mono text-[11px] text-[#E6EDF3]">{eaInfo.data ? `${(eaInfo.data.file_size_bytes / 1024).toFixed(1)} KB` : "—"}</dd>
              </div>
              <div className="flex items-center justify-between gap-2">
                <dt className="font-mono text-[10px] tracking-[0.16em] text-[#6B7280]">STORAGE</dt>
                <dd className="font-mono text-[11px] text-[#E6EDF3]">server-side private directory · license-gated route</dd>
              </div>
            </dl>
            <p className="mt-5 rounded-md border border-[#D4AF37]/25 bg-[#0D1117] p-4 text-xs leading-relaxed text-[#9CA3AF]">
              The EX5 is stored outside the public web directory and served only through the authorized,
              license-gated download route. The MQ5 source is never exposed through any endpoint. A copied EX5
              cannot operate on an unauthorized MT5 account — the license server refuses validation.
            </p>
          </div>
        </div>
      )}

      {tab === "logs" && (
        <div className="space-y-5" data-testid="admin-logs-panel">
          <h1 className="font-heading text-xl font-bold tracking-tight text-white">AUDIT LOGS</h1>
          <div className="rounded-lg border border-[#242B3A] bg-[#161B26]">
            <Table data-testid="admin-logs-table">
              <TableHeader>
                <TableRow className="border-[#242B3A] hover:bg-transparent">
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">TIME</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">ACTOR</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">ACTION</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">TARGET</TableHead>
                  <TableHead className="font-mono text-[9px] tracking-[0.16em] text-[#6B7280]">DETAILS</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(logs.data ?? []).map((log) => (
                  <TableRow key={log.id} className="border-[#242B3A]">
                    <TableCell className="whitespace-nowrap font-mono text-[10px] text-[#6B7280]">{formatDate(log.created_at)}</TableCell>
                    <TableCell className="whitespace-nowrap font-mono text-[11px] text-[#C7CCD6]">{log.actor}</TableCell>
                    <TableCell className="whitespace-nowrap font-mono text-[10px] tracking-[0.1em] text-[#F5D77F]">{log.action}</TableCell>
                    <TableCell className="whitespace-nowrap font-mono text-[11px] text-[#9CA3AF]">{log.target_email ?? "—"}</TableCell>
                    <TableCell className="text-sm text-[#9CA3AF]">{log.details}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            {(logs.data ?? []).length === 0 && <p className="p-6 text-center text-sm text-[#6B7280]">No audit entries yet.</p>}
          </div>
        </div>
      )}

      {tab === "settings" && (
        <div className="max-w-3xl space-y-5" data-testid="admin-settings-panel">
          <h1 className="font-heading text-xl font-bold tracking-tight text-white">SETTINGS</h1>
          <div className="grid gap-4 sm:grid-cols-3">
            <div className="rounded-lg border border-[#242B3A] bg-[#161B26] p-5">
              <p className="font-mono text-[9px] uppercase tracking-[0.2em] text-[#6B7280]">EA VERSION</p>
              <p className="mt-2 font-mono text-lg text-[#F5D77F]">{statsData?.settings.ea_version ?? "—"}</p>
            </div>
            <div className="rounded-lg border border-[#242B3A] bg-[#161B26] p-5">
              <p className="font-mono text-[9px] uppercase tracking-[0.2em] text-[#6B7280]">LICENSE VALIDITY</p>
              <p className="mt-2 font-mono text-lg text-[#F5D77F]">{statsData?.settings.license_validity_months ?? "—"} months</p>
            </div>
            <div className="rounded-lg border border-[#242B3A] bg-[#161B26] p-5">
              <p className="font-mono text-[9px] uppercase tracking-[0.2em] text-[#6B7280]">SESSION TTL</p>
              <p className="mt-2 font-mono text-lg text-[#F5D77F]">{statsData?.settings.session_ttl_hours ?? "—"} hours</p>
            </div>
          </div>
          <div className="rounded-lg border border-[#242B3A] bg-[#161B26] p-6">
            <h2 className="font-heading text-base font-semibold tracking-tight text-white">SECURITY POSTURE</h2>
            <ul className="mt-4 space-y-2.5 text-sm text-[#9CA3AF]">
              {[
                "Passwords hashed (PBKDF2-SHA256) — never stored or logged in plaintext",
                "JWT session cookies: httpOnly, SameSite=Lax, signed with a server-side secret",
                "Server-side session store — signing out revokes the session everywhere",
                "Rate limiting on authentication, registration and license-check endpoints",
                "Admin and customer routes authorized server-side, per request",
                "EX5 stored in a private server directory; MQ5 source never distributed",
                "Audit trail on every approval, revocation, suspension and download",
              ].map((item) => (
                <li key={item} className="flex items-start gap-2.5">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[#D4AF37]" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {/* confirm dialog */}
      <ConfirmDialog
        open={confirm !== null}
        onOpenChange={(open) => {
          if (!open) setConfirm(null);
        }}
        title={confirm?.title ?? ""}
        description={confirm?.description ?? ""}
        confirmLabel={confirm?.confirmLabel ?? "CONFIRM"}
        destructive={confirm?.destructive ?? false}
        loading={act.isPending}
        testIdPrefix={confirm ? `admin-${confirm.action}-${confirm.id}` : "admin-action"}
        onConfirm={() => {
          if (confirm) act.mutate({ id: confirm.id, action: confirm.action });
        }}
      />

      {/* extend dialog */}
      <Dialog
        open={extendTarget !== null}
        onOpenChange={(open) => {
          if (!open) setExtendTarget(null);
        }}
      >
        <DialogContent className="max-w-md border-[#D4AF37]/25 bg-[#12161F]">
          <DialogHeader>
            <DialogTitle className="font-heading tracking-tight text-white">EXTEND LICENSE</DialogTitle>
            <DialogDescription className="text-[#9CA3AF]">
              Extend the license of {extendTarget?.full_name ?? "—"} beyond{" "}
              {formatDate(extendTarget?.expiry_date ?? null)}.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <p className="font-mono text-[10px] tracking-[0.18em] text-[#9CA3AF]">EXTEND BY</p>
            <Select value={extendMonths} onValueChange={(v: string) => setExtendMonths(v)}>
              <SelectTrigger className="border-[#242B3A] bg-[#0D1117]" data-testid="admin-extend-months-select">
                <SelectValue>{`${extendMonths} months`}</SelectValue>
              </SelectTrigger>
              <SelectContent className="border-[#242B3A] bg-[#12161F]">
                {["3", "6", "12", "24"].map((m) => (
                  <SelectItem key={m} value={m} data-testid={`admin-extend-months-${m}`}>
                    {m} months
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setExtendTarget(null)} data-testid="admin-extend-cancel-button">
              Cancel
            </Button>
            <Button
              disabled={act.isPending}
              onClick={() => {
                if (extendTarget) {
                  act.mutate({ id: extendTarget.id, action: "extend", months: Number(extendMonths) });
                  setExtendTarget(null);
                }
              }}
              data-testid="admin-extend-confirm-button"
            >
              {act.isPending && <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />}
              <Play className="mr-1.5 h-4 w-4" />
              APPLY EXTENSION
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* view dialog */}
      <Dialog
        open={viewId !== null}
        onOpenChange={(open) => {
          if (!open) setViewId(null);
        }}
      >
        <DialogContent className="max-w-2xl border-[#D4AF37]/25 bg-[#12161F]">
          <DialogHeader>
            <DialogTitle className="font-heading tracking-tight text-white">APPLICATION DETAIL</DialogTitle>
            <DialogDescription className="text-[#9CA3AF]">
              {detail.data?.user.email ?? "Loading…"}
            </DialogDescription>
          </DialogHeader>
          {detail.data && (
            <div className="space-y-5" data-testid="admin-view-detail">
              <div className="grid gap-3 sm:grid-cols-3">
                {[
                  ["FULL NAME", detail.data.user.full_name],
                  ["PHONE", detail.data.user.phone],
                  ["MT5 ACCOUNT", detail.data.user.mt5_account],
                  ["BROKER", detail.data.user.broker],
                  ["SERVER", detail.data.user.mt5_server],
                  ["LICENSE ID", detail.data.user.license_id ?? "—"],
                  ["ACTIVATION", formatDate(detail.data.user.activation_date)],
                  ["EXPIRY", formatDate(detail.data.user.expiry_date)],
                  ["EA VERSION", detail.data.user.ea_version ?? "—"],
                ].map(([label, value]) => (
                  <div key={label} className="rounded-md border border-[#242B3A] bg-[#0E121A] p-3">
                    <p className="font-mono text-[9px] tracking-[0.18em] text-[#6B7280]">{label}</p>
                    <p className="mt-1 break-all font-mono text-xs text-[#E6EDF3]">{value}</p>
                  </div>
                ))}
              </div>
              <div className="rounded-md border border-[#242B3A] bg-[#0E121A] p-4">
                <p className="font-mono text-[9px] tracking-[0.18em] text-[#6B7280]">AUDIT TRAIL</p>
                <ul className="mt-3 space-y-2">
                  {detail.data.logs.slice(0, 8).map((log) => (
                    <li key={log.id} className="flex flex-wrap gap-2 font-mono text-[10px]">
                      <span className="text-[#4B5563]">{formatDate(log.created_at)}</span>
                      <span className="text-[#F5D77F]">{log.action}</span>
                      <span className="text-[#9CA3AF]">{log.details}</span>
                    </li>
                  ))}
                  {detail.data.logs.length === 0 && <li className="text-xs text-[#6B7280]">No entries for this user.</li>}
                </ul>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
      <Toaster />
    </DashboardShell>
  );
}
