import { Lock, Server, Trash2, Eye, FileKey, Globe } from "lucide-react";
import { Reveal } from "@/components/Reveal";

const SECTIONS = [
  {
    icon: FileKey,
    title: "What we collect",
    body: "When you apply for EA access we collect your full name, email address, phone number, MT5 account number, broker name and MT5 server name — the minimum required to issue and bind a license. Portal sessions are stored server-side; passwords are stored only as salted hashes.",
  },
  {
    icon: Server,
    title: "Where data lives",
    body: "Application and license data is stored in the platform's server-side database. License validation requests from the EA are processed server-side and rate-limited. We do not publish application data.",
  },
  {
    icon: Eye,
    title: "How data is used",
    body: "Your information is used to administer the IB program, verify your MT5 binding, operate the license server, maintain the audit trail and provide support. Administrative actions on your license (approval, suspension, revocation, extension) are logged.",
  },
  {
    icon: Lock,
    title: "Security measures",
    body: "Passwords are hashed with PBKDF2-SHA256. Sessions are signed JWTs delivered in httpOnly cookies and revocable server-side. Admin and customer routes are authorized on every request. The compiled EX5 is stored in a private server directory and served only through a license-gated route. The MQ5 source is never distributed.",
  },
  {
    icon: Trash2,
    title: "Retention and deletion",
    body: "Application records are retained while a license is under review or active. You may request deletion of your personal data by contacting the platform desk; license and audit records may be retained where required for the integrity of the licensing system.",
  },
  {
    icon: Globe,
    title: "Third-party services",
    body: "The Live Markets page embeds the public TradingView chart widget, which is governed by TradingView's own terms and privacy policy. We do not send your portal credentials or license data to third parties.",
  },
];

export default function Privacy() {
  return (
    <div className="carbon-dots mx-auto max-w-4xl px-4 py-14 sm:px-6 lg:py-20">
      <Reveal>
        <p className="font-mono text-[11px] uppercase tracking-[0.28em] text-[#D4AF37]">LEGAL</p>
        <h1 className="mt-3 font-heading text-3xl font-bold tracking-tight text-white sm:text-4xl">
          PRIVACY POLICY
        </h1>
        <p className="mt-4 text-sm text-[#6B7280]">
          How BLACKSTONE FX handles your data · Automated Trading Technology
        </p>
      </Reveal>

      <div className="mt-10 grid gap-5 sm:grid-cols-2">
        {SECTIONS.map((section, i) => {
          const Icon = section.icon;
          return (
            <Reveal key={section.title} delay={i * 0.04}>
              <section className="h-full rounded-lg border border-[#242B3A] bg-[#161B26] p-6" data-testid={`privacy-section-${i + 1}`}>
                <Icon className="h-5 w-5 text-[#D4AF37]" />
                <h2 className="mt-4 font-heading text-base font-semibold tracking-tight text-white">{section.title}</h2>
                <p className="mt-2.5 text-sm leading-relaxed text-[#9CA3AF]">{section.body}</p>
              </section>
            </Reveal>
          );
        })}
      </div>

      <Reveal delay={0.1}>
        <p className="mt-10 rounded-lg border border-[#242B3A] bg-[#161B26] p-5 text-xs leading-relaxed text-[#6B7280]">
          Data protection questions? Contact the platform desk at the address listed in the footer. We never
          publish, sell or share your personal data with unconnected third parties.
        </p>
      </Reveal>
    </div>
  );
}
