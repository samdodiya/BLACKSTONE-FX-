import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { ArrowUpRight, Check, Copy, ExternalLink, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { apiPost } from "@/lib/api";
import { errorDetail } from "@/lib/errors";
import type { RegisterResponse } from "@/lib/types";
import { Button, buttonVariants } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { StatusBadge } from "@/components/StatusBadge";
import { Reveal } from "@/components/Reveal";

const REFERRAL_URL = "https://vigco.co/la-com-inv/TRI3lX2K";
const REFERRAL_CODE = "TRI3lX2K";

const STEPS = [
  { title: "JOIN THROUGH THE OFFICIAL IB REFERRAL", text: "Create your account using the official referral link and code before applying for EA access." },
  { title: "SUBMIT ACCOUNT INFORMATION", text: "Provide your name, contact details and the exact MT5 account number, broker and server you will run the EA on." },
  { title: "ADMIN REVIEWS THE APPLICATION", text: "Your application enters review with status PENDING. Nothing is automated away — a human verifies the binding." },
  { title: "ADMIN APPROVES THE ACCOUNT", text: "On approval your IB status becomes APPROVED and the license is prepared for activation." },
  { title: "LICENSE BECOMES ACTIVE", text: "The account-bound license is activated with a license ID and a defined expiry date." },
  { title: "EX5 DOWNLOAD ACCESS", text: "The compiled Blackstone EA (EX5) becomes available in your portal. The MQ5 source is never distributed." },
  { title: "INSTALL THE EA IN MT5", text: "Attach the EA to an approved chart in your MT5 terminal — the same account you registered." },
  { title: "EA VALIDATES WITH THE LICENSE SERVER", text: "The EA operates only when the account is approved, the broker/server match the record, the license is active and not expired or revoked." },
];

interface FormState {
  full_name: string;
  email: string;
  phone: string;
  mt5_account: string;
  broker: string;
  mt5_server: string;
  password: string;
}

const EMPTY: FormState = {
  full_name: "",
  email: "",
  phone: "",
  mt5_account: "",
  broker: "",
  mt5_server: "",
  password: "",
};

export default function Access() {
  const [form, setForm] = useState<FormState>(EMPTY);
  const [submitted, setSubmitted] = useState<RegisterResponse | null>(null);
  const [copied, setCopied] = useState<"code" | "link" | null>(null);

  const mutation = useMutation({
    mutationFn: (body: FormState) => apiPost<RegisterResponse>("/register", body),
    onSuccess: (data) => {
      setSubmitted(data);
      toast.success("Application received — status PENDING. Save your credentials.");
    },
    onError: (err) => toast.error(errorDetail(err, "Registration failed. Please review your details.")),
  });

  const set = (key: keyof FormState) => (value: string) => setForm((f) => ({ ...f, [key]: value }));

  const copy = async (kind: "code" | "link", value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(kind);
      toast.success(kind === "code" ? "Referral code copied." : "Referral link copied.");
      setTimeout(() => setCopied(null), 2000);
    } catch {
      toast.error("Clipboard unavailable — copy the value manually.");
    }
  };

  return (
    <div className="carbon-dots mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:py-16">
      <Reveal>
        <p className="font-mono text-[11px] uppercase tracking-[0.28em] text-[#D4AF37]">IB ACCESS GATEWAY</p>
        <h1 className="mt-3 font-heading text-3xl font-bold tracking-tight text-white sm:text-4xl">ACCESS</h1>
        <p className="mt-4 max-w-2xl text-[#9CA3AF]">
          Eight steps stand between this page and an automated MT5 chart. Every license is bound to one account,
          one broker, one server.
        </p>
      </Reveal>

      <div className="mt-12 grid gap-10 lg:grid-cols-2">
        {/* roadmap */}
        <div className="relative" data-testid="access-steps">
          <div className="absolute bottom-4 left-[19px] top-4 w-px bg-gradient-to-b from-[#D4AF37]/50 via-[#242B3A] to-transparent" aria-hidden="true" />
          <ol className="space-y-6">
            {STEPS.map((step, i) => (
              <li key={step.title} className="relative flex gap-5" data-testid={`access-step-${i + 1}`}>
                <span className="z-10 flex h-10 w-10 shrink-0 items-center justify-center rounded-md border border-[#D4AF37]/40 bg-[#2A2312] font-mono text-xs font-semibold text-[#F5D77F]">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <div className="rounded-lg border border-[#242B3A] bg-[#161B26] p-5 transition-colors duration-200 hover:border-[#D4AF37]/40">
                  <h3 className="font-mono text-xs font-semibold tracking-[0.16em] text-white">{step.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-[#9CA3AF]">{step.text}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>

        {/* referral + form */}
        <div className="space-y-6">
          <Reveal delay={0.05}>
            <div className="glass-panel gold-glow rounded-xl border border-[#D4AF37]/25 p-6" data-testid="access-referral-card">
              <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-[#D4AF37]">STEP 1 · OFFICIAL IB REFERRAL</p>
              <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center">
                <div className="flex-1 rounded-md border border-[#242B3A] bg-[#0D1117] px-4 py-3">
                  <p className="font-mono text-[9px] tracking-[0.2em] text-[#6B7280]">REFERRAL CODE</p>
                  <p className="font-mono text-lg font-semibold tracking-[0.18em] text-[#F5D77F]">{REFERRAL_CODE}</p>
                </div>
                <Button variant="outline" size="sm" onClick={() => copy("code", REFERRAL_CODE)} data-testid="copy-referral-code-button">
                  {copied === "code" ? <Check className="mr-1.5 h-4 w-4 text-[#34D399]" /> : <Copy className="mr-1.5 h-4 w-4" />}
                  COPY CODE
                </Button>
              </div>
              <a
                href={REFERRAL_URL}
                target="_blank"
                rel="noopener noreferrer"
                className={`${buttonVariants({ size: "sm" })} mt-4 w-full`}
                data-testid="open-ib-referral-link"
              >
                OPEN IB REFERRAL LINK
                <ExternalLink className="ml-2 h-4 w-4" />
              </a>
              <p className="mt-3 break-all font-mono text-[10px] leading-relaxed text-[#6B7280]">{REFERRAL_URL}</p>
            </div>
          </Reveal>

          <Reveal delay={0.08}>
            {submitted ? (
              <div className="rounded-xl border border-[#10B981]/40 bg-[#06281E]/60 p-8" data-testid="access-success-card">
                <div className="flex h-12 w-12 items-center justify-center rounded-full border border-[#34D399]/50 bg-[#06281E]">
                  <Check className="h-6 w-6 text-[#34D399]" />
                </div>
                <h2 className="mt-5 font-heading text-xl font-bold tracking-tight text-white">
                  APPLICATION RECEIVED
                </h2>
                <p className="mt-3 text-sm leading-relaxed text-[#9CA3AF]">
                  Your application is in review. Keep this email for the Client Portal — you will use it to sign
                  in and monitor your license.
                </p>
                <div className="mt-5 space-y-2.5 rounded-md border border-[#242B3A] bg-[#0D1117] p-4">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-[10px] tracking-[0.18em] text-[#6B7280]">EMAIL</span>
                    <span className="font-mono text-xs text-[#E6EDF3]">{form.email}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-[10px] tracking-[0.18em] text-[#6B7280]">MT5 ACCOUNT</span>
                    <span className="font-mono text-xs text-[#E6EDF3]">{form.mt5_account}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-[10px] tracking-[0.18em] text-[#6B7280]">STATUS</span>
                    <StatusBadge status="PENDING" testId="access-success-status-badge" />
                  </div>
                </div>
                <p className="mt-4 flex items-start gap-2 text-xs leading-relaxed text-[#6B7280]">
                  <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-[#D4AF37]" />
                  The EA will only operate on the approved MT5 account, broker and server — after an administrator
                  activates your license.
                </p>
              </div>
            ) : (
              <form
                className="rounded-xl border border-[#242B3A] bg-[#161B26] p-6 sm:p-8"
                onSubmit={(e) => {
                  e.preventDefault();
                  mutation.mutate(form);
                }}
                data-testid="access-registration-form"
              >
                <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-[#D4AF37]">
                  STEP 2 · SUBMIT ACCOUNT INFORMATION
                </p>
                <h2 className="mt-3 font-heading text-xl font-bold tracking-tight text-white">
                  EA ACCESS APPLICATION
                </h2>

                <div className="mt-6 grid gap-4 sm:grid-cols-2">
                  <div className="sm:col-span-2">
                    <Label htmlFor="reg-full-name" className="font-mono text-[10px] tracking-[0.18em] text-[#9CA3AF]">
                      FULL NAME
                    </Label>
                    <Input
                      id="reg-full-name"
                      required
                      minLength={2}
                      value={form.full_name}
                      onChange={(e) => set("full_name")(e.target.value)}
                      placeholder="As shown on your trading account"
                      className="mt-1.5 border-[#242B3A] bg-[#0D1117]"
                      data-testid="registration-full-name-input"
                    />
                  </div>
                  <div>
                    <Label htmlFor="reg-email" className="font-mono text-[10px] tracking-[0.18em] text-[#9CA3AF]">
                      EMAIL
                    </Label>
                    <Input
                      id="reg-email"
                      type="email"
                      required
                      value={form.email}
                      onChange={(e) => set("email")(e.target.value)}
                      placeholder="you@example.com"
                      className="mt-1.5 border-[#242B3A] bg-[#0D1117]"
                      data-testid="registration-email-input"
                    />
                  </div>
                  <div>
                    <Label htmlFor="reg-phone" className="font-mono text-[10px] tracking-[0.18em] text-[#9CA3AF]">
                      PHONE
                    </Label>
                    <Input
                      id="reg-phone"
                      type="tel"
                      required
                      minLength={7}
                      value={form.phone}
                      onChange={(e) => set("phone")(e.target.value)}
                      placeholder="+971 50 000 0000"
                      className="mt-1.5 border-[#242B3A] bg-[#0D1117]"
                      data-testid="registration-phone-input"
                    />
                  </div>
                  <div>
                    <Label htmlFor="reg-mt5-account" className="font-mono text-[10px] tracking-[0.18em] text-[#9CA3AF]">
                      MT5 ACCOUNT NUMBER
                    </Label>
                    <Input
                      id="reg-mt5-account"
                      required
                      inputMode="numeric"
                      pattern="\d{4,20}"
                      title="Numeric MT5 account number (4–20 digits)"
                      value={form.mt5_account}
                      onChange={(e) => set("mt5_account")(e.target.value.replace(/\D/g, ""))}
                      placeholder="e.g. 5100001"
                      className="mt-1.5 border-[#242B3A] bg-[#0D1117]"
                      data-testid="registration-mt5-account-input"
                    />
                  </div>
                  <div>
                    <Label htmlFor="reg-broker" className="font-mono text-[10px] tracking-[0.18em] text-[#9CA3AF]">
                      BROKER
                    </Label>
                    <Input
                      id="reg-broker"
                      required
                      minLength={2}
                      value={form.broker}
                      onChange={(e) => set("broker")(e.target.value)}
                      placeholder="e.g. IC Markets"
                      className="mt-1.5 border-[#242B3A] bg-[#0D1117]"
                      data-testid="registration-broker-input"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <Label htmlFor="reg-mt5-server" className="font-mono text-[10px] tracking-[0.18em] text-[#9CA3AF]">
                      MT5 SERVER
                    </Label>
                    <Input
                      id="reg-mt5-server"
                      required
                      minLength={2}
                      value={form.mt5_server}
                      onChange={(e) => set("mt5_server")(e.target.value)}
                      placeholder="e.g. ICMarketsSC-MT5"
                      className="mt-1.5 border-[#242B3A] bg-[#0D1117]"
                      data-testid="registration-mt5-server-input"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <Label htmlFor="reg-password" className="font-mono text-[10px] tracking-[0.18em] text-[#9CA3AF]">
                      PORTAL PASSWORD (MIN. 8 CHARACTERS)
                    </Label>
                    <Input
                      id="reg-password"
                      type="password"
                      required
                      minLength={8}
                      value={form.password}
                      onChange={(e) => set("password")(e.target.value)}
                      placeholder="For signing in to the Client Portal"
                      className="mt-1.5 border-[#242B3A] bg-[#0D1117]"
                      data-testid="registration-password-input"
                    />
                    <p className="mt-2 flex items-center gap-1.5 text-[11px] text-[#6B7280]">
                      <ArrowUpRight className="h-3 w-3 text-[#D4AF37]" />
                      You will use this password to sign in to the Client Portal and monitor your license.
                    </p>
                  </div>
                </div>

                <Button
                  type="submit"
                  size="lg"
                  className="mt-7 w-full"
                  disabled={mutation.isPending}
                  data-testid="registration-submit-button"
                >
                  {mutation.isPending ? "SUBMITTING…" : "SUBMIT APPLICATION"}
                </Button>
                <p className="mt-4 text-center text-[11px] leading-relaxed text-[#6B7280]">
                  Submitting creates a PENDING application for admin review. Access is subject to approval and
                  the platform's risk disclosure.
                </p>
              </form>
            )}
          </Reveal>
        </div>
      </div>
    </div>
  );
}
