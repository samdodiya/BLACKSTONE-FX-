import { Link } from "react-router-dom";
import { motion } from "motion/react";
import {
  ArrowRight,
  Bot,
  Fingerprint,
  Globe,
  Layers,
  Lock,
  MonitorSmartphone,
  RefreshCcw,
  ShieldCheck,
  Zap,
} from "lucide-react";
import { buttonVariants } from "@/components/ui/button";
import { HeroPanel } from "@/components/home/HeroPanel";
import { TickerRibbon } from "@/components/trading/TickerRibbon";
import { Reveal } from "@/components/Reveal";

const STRIP = [
  { icon: Bot, label: "BLACKSTONE EA" },
  { icon: Globe, label: "XAUUSD" },
  { icon: MonitorSmartphone, label: "MT5 AUTOMATION" },
  { icon: ShieldCheck, label: "RISK MANAGEMENT" },
  { icon: Layers, label: "BASKET CONTROL" },
  { icon: Lock, label: "ACCOUNT SECURITY" },
];

const EA_FEATURES = [
  {
    icon: Zap,
    title: "Advanced Execution",
    description:
      "Structured order placement with configurable entry logic — engineered for fast-moving metals and FX conditions on MT5.",
  },
  {
    icon: ShieldCheck,
    title: "Risk Management",
    description:
      "Configurable exposure limits, equity guards and drawdown protection. The EA operates strictly inside the risk envelope you define.",
  },
  {
    icon: RefreshCcw,
    title: "Recovery System",
    description:
      "A disciplined, rules-based mechanism for adverse price sequences, governed by hard, system-defined caps — never unlimited averaging.",
  },
  {
    icon: Layers,
    title: "Basket Management",
    description:
      "Positions are managed as coordinated baskets: controlled scaling, weighted exits and unified basket-level risk accounting.",
  },
  {
    icon: Fingerprint,
    title: "Account Security",
    description:
      "Every license is bound to the MT5 account number, broker and server. The EA operates only where it is authorized to operate.",
  },
  {
    icon: Bot,
    title: "Automated MT5 Execution",
    description:
      "Built for MetaTrader 5. Fully automated cycles from signal detection to position close — under your configured controls.",
  },
];

const FLOW = [
  { step: "01", title: "Join IB", text: "Register through the official referral and submit your MT5 details." },
  { step: "02", title: "Admin Review", text: "Your application is verified — account, broker and server binding." },
  { step: "03", title: "License Active", text: "On approval, your account-bound license is activated with an expiry date." },
  { step: "04", title: "EX5 Download", text: "Download the compiled EA, install it in MT5 and connect to the license server." },
];

const HERO_CHIPS = [
  { label: "MT5 READY", tone: "border-[#10B981]/40 text-[#34D399]", dot: "bg-[#34D399]" },
  { label: "ACCOUNT-BOUND LICENSE", tone: "border-[#D4AF37]/40 text-[#F5D77F]", dot: "bg-[#D4AF37]" },
  { label: "ADMIN APPROVAL", tone: "border-[#D4AF37]/40 text-[#F5D77F]", dot: "bg-[#D4AF37]" },
];

export default function Home() {
  return (
    <div className="carbon-dots">
      {/* ---------------- HERO ---------------- */}
      <section className="relative overflow-hidden" data-testid="home-hero">
        <div
          className="pointer-events-none absolute inset-0 bg-cover bg-center opacity-25"
          style={{ backgroundImage: "url(/hero-core.jpg)" }}
          aria-hidden="true"
        />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-[#0B0D11]/60 via-[#0B0D11]/80 to-[#0B0D11]" aria-hidden="true" />
        <div className="hero-ambient hero-ambient-one" aria-hidden="true" />
        <div className="hero-ambient hero-ambient-two" aria-hidden="true" />

        <div className="relative mx-auto grid max-w-7xl grid-cols-1 items-center gap-12 px-4 pb-20 pt-16 sm:px-6 lg:grid-cols-12 lg:pb-28 lg:pt-24">
          <motion.div
            className="lg:col-span-7"
            initial={{ opacity: 0, x: -24 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
          >
            <p className="hero-overline font-mono text-[11px] uppercase tracking-[0.28em] text-[#D4AF37]" data-testid="hero-overline">
              BLACKSTONE FX • AUTOMATED TRADING SYSTEM
            </p>
            <motion.h1
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.75, delay: 0.12, ease: "easeOut" }}
              className="mt-6 font-heading text-5xl font-extrabold leading-[0.95] tracking-tight text-white sm:text-6xl lg:text-7xl">
              TRADE.
              <br />
              AUTOMATE.
              <br />
              <span className="bg-gradient-to-r from-[#F5D77F] via-[#D4AF37] to-[#B8912B] bg-clip-text text-transparent">
                CONTROL.
              </span>
            </motion.h1>
            <p className="mt-7 max-w-xl text-base leading-relaxed text-[#9CA3AF] sm:text-lg">
              A premium MT5 ecosystem built around structured execution, configurable risk controls and
              account-bound EA access. Built for traders who treat automation as infrastructure — not a lottery
              ticket.
            </p>

            <div className="mt-9 flex flex-col gap-3 sm:flex-row sm:items-center">
              <Link to="/access" className={buttonVariants({ size: "lg" })} data-testid="hero-cta-join-ib">
                JOIN IB &amp; GET ACCESS
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
              <Link
                to="/ea-intelligence"
                className={buttonVariants({ variant: "outline", size: "lg" })}
                data-testid="hero-cta-explore-ea"
              >
                EXPLORE BLACKSTONE EA
              </Link>
            </div>

            <div className="mt-9 flex flex-wrap gap-2.5">
              {HERO_CHIPS.map((chip) => (
                <span
                  key={chip.label}
                  className={`flex items-center gap-2 rounded-full border bg-[#0E121A]/80 px-3 py-1.5 font-mono text-[10px] tracking-[0.18em] ${chip.tone}`}
                >
                  <span className={`live-dot inline-block h-1.5 w-1.5 rounded-full ${chip.dot}`} />
                  {chip.label}
                </span>
              ))}
            </div>
          </motion.div>

          <motion.div
            className="hero-float lg:col-span-5 lg:pl-4"
            initial={{ opacity: 0, x: 24, scale: 0.97 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.18, ease: "easeOut" }}
          >
            <HeroPanel />
          </motion.div>
        </div>
      </section>

      <TickerRibbon />

      {/* ---------------- FEATURE STRIP ---------------- */}
      <section className="border-b border-[#242B3A] bg-[#12161F]/60" data-testid="home-feature-strip">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-px px-4 sm:px-6 md:grid-cols-3 lg:grid-cols-6">
          {STRIP.map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.label}
                className="feature-strip-item flex flex-col items-center gap-2.5 border border-transparent px-4 py-7 text-center transition-colors duration-200 hover:border-[#D4AF37]/30"
              >
                <Icon className="h-5 w-5 text-[#D4AF37]" />
                <span className="font-mono text-[10px] tracking-[0.2em] text-[#C7CCD6]">{item.label}</span>
              </div>
            );
          })}
        </div>
      </section>

      {/* ---------------- EA PRODUCT SECTION ---------------- */}
      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:py-28" data-testid="home-ea-section">
        <Reveal>
          <p className="font-mono text-[11px] uppercase tracking-[0.28em] text-[#D4AF37]">PRODUCT</p>
          <div className="mt-4 flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
            <div>
              <h2 className="font-heading text-3xl font-bold tracking-tight text-white sm:text-4xl">
                BLACKSTONE EA
              </h2>
              <p className="mt-3 max-w-2xl text-[#9CA3AF]">
                Automated execution with structured risk and account-bound access.
              </p>
            </div>
            <Link
              to="/ea-intelligence"
              className="group inline-flex items-center gap-2 font-mono text-xs uppercase tracking-[0.2em] text-[#D4AF37] hover:text-[#F5D77F]"
              data-testid="home-ea-learn-more"
            >
              FULL SYSTEM BRIEFING
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </div>
        </Reveal>

        <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {EA_FEATURES.map((feature, i) => {
            const Icon = feature.icon;
            return (
              <Reveal key={feature.title} delay={i * 0.05}>
                <div
                  className="hover-gold group h-full rounded-lg border border-[#242B3A] bg-[#161B26] p-6"
                  data-testid={`ea-feature-card-${feature.title.toLowerCase().replace(/\s+/g, "-")}`}
                >
                  <div className="flex h-11 w-11 items-center justify-center rounded-md border border-[#D4AF37]/30 bg-[#2A2312] transition-colors duration-200 group-hover:border-[#D4AF37]/60">
                    <Icon className="h-5 w-5 text-[#D4AF37]" />
                  </div>
                  <h3 className="mt-5 font-heading text-lg font-semibold tracking-tight text-white">
                    {feature.title}
                  </h3>
                  <p className="mt-2.5 text-sm leading-relaxed text-[#9CA3AF]">{feature.description}</p>
                </div>
              </Reveal>
            );
          })}
        </div>
      </section>

      {/* ---------------- LICENSING FLOW ---------------- */}
      <section className="border-y border-[#242B3A] bg-[#0E121A]" data-testid="home-flow-section">
        <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
          <Reveal>
            <p className="font-mono text-[11px] uppercase tracking-[0.28em] text-[#D4AF37]">ACCESS PROTOCOL</p>
            <h2 className="mt-4 font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl">
              From application to automated execution
            </h2>
          </Reveal>
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {FLOW.map((item, i) => (
              <Reveal key={item.step} delay={i * 0.06}>
                <div className="relative h-full rounded-lg border border-[#242B3A] bg-[#12161F] p-6" data-testid={`home-flow-step-${item.step}`}>
                  <span className="font-mono text-2xl font-semibold text-[#D4AF37]/50">{item.step}</span>
                  <h3 className="mt-3 font-heading text-base font-semibold tracking-tight text-white">
                    {item.title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-[#9CA3AF]">{item.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
          <Reveal delay={0.1}>
            <div className="mt-10 flex flex-col items-start gap-4 sm:flex-row sm:items-center sm:justify-between">
              <p className="max-w-xl text-sm leading-relaxed text-[#6B7280]">
                Access is administered manually — every license is bound to one MT5 account, one broker and one
                server, and remains subject to review.
              </p>
              <Link to="/access" className={buttonVariants({})} data-testid="home-flow-cta">
                START THE APPLICATION
              </Link>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ---------------- CTA BANNER ---------------- */}
      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6" data-testid="home-cta-banner">
        <Reveal>
          <div className="glass-panel gold-glow relative overflow-hidden rounded-xl border border-[#D4AF37]/25 p-10 text-center sm:p-14">
            <p className="font-mono text-[11px] uppercase tracking-[0.28em] text-[#D4AF37]">
              BLACKSTONE FX • AUTOMATED TRADING SYSTEM
            </p>
            <h2 className="mx-auto mt-5 max-w-2xl font-heading text-3xl font-bold tracking-tight text-white sm:text-4xl">
              Structure your automation. Control your risk.
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-sm leading-relaxed text-[#9CA3AF]">
              Trading financial markets involves substantial risk. Past performance does not guarantee future
              results. BLACKSTONE FX does not guarantee profits.
            </p>
            <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <Link to="/access" className={buttonVariants({ size: "lg" })} data-testid="home-banner-cta-join">
                JOIN IB &amp; GET ACCESS
              </Link>
              <Link
                to="/markets"
                className={buttonVariants({ variant: "outline", size: "lg" })}
                data-testid="home-banner-cta-markets"
              >
                VIEW LIVE MARKETS
              </Link>
            </div>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
