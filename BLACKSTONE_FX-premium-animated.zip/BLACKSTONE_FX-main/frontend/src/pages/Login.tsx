import { useState } from "react";
import { motion } from "motion/react";
import { Link, useNavigate } from "react-router-dom";
import { useMutation } from "@tanstack/react-query";
import { ArrowLeft, Loader2, Lock, ShieldCheck, User } from "lucide-react";
import { toast } from "sonner";
import { apiPost } from "@/lib/api";
import { errorDetail } from "@/lib/errors";
import { beginSession } from "@/lib/session";
import type { SessionIdentity } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Toaster } from "@/components/ui/sonner";
import { Logo, LogoMark } from "@/components/Logo";

type LoginMode = "customer" | "admin";

export default function Login() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<LoginMode>("customer");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");

  const login = useMutation({
    mutationFn: (payload: { path: string; body: Record<string, string> }) =>
      apiPost<SessionIdentity>(payload.path, payload.body),
    onSuccess: (identity) => {
      beginSession();
      toast.success(identity.role === "admin" ? "Administrator session established." : "Welcome back.");
      navigate(identity.role === "admin" ? "/admin" : "/portal", { replace: true });
    },
    onError: (err) => toast.error(errorDetail(err, "Sign-in failed. Check your credentials.")),
  });

  const submitCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    login.mutate({ path: "/auth/customer/login", body: { email, password } });
  };

  const submitAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    login.mutate({ path: "/auth/admin/login", body: { username, password } });
  };

  return (
    <div className="flex min-h-svh bg-[#0B0D11] text-[#F3F4F6]" data-testid="login-page">
      {/* brand panel */}
      <div className="relative hidden flex-1 overflow-hidden border-r border-[#242B3A] lg:block">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-25"
          style={{ backgroundImage: "url(/hero-core.jpg)" }}
          aria-hidden="true"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B0D11] via-[#0B0D11]/70 to-[#0B0D11]/40" aria-hidden="true" />
        <motion.div initial={{ opacity: 0, x: -14 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.55, ease: "easeOut" }} className="relative flex h-full flex-col justify-between p-12">
          <Link to="/" data-testid="login-logo-link">
            <Logo />
          </Link>
          <div>
            <p className="font-mono text-[11px] uppercase tracking-[0.28em] text-[#D4AF37]">
              BLACKSTONE FX • AUTOMATED TRADING SYSTEM
            </p>
            <p className="mt-5 max-w-md font-heading text-3xl font-bold leading-tight tracking-tight text-white">
              Trade. Automate. Control.
            </p>
            <ul className="mt-8 space-y-3">
              {["Account-bound EA licensing", "Server-side license validation", "Protected EX5 distribution"].map(
                (item) => (
                  <li key={item} className="flex items-center gap-3 text-sm text-[#9CA3AF]">
                    <ShieldCheck className="h-4 w-4 text-[#D4AF37]" />
                    {item}
                  </li>
                ),
              )}
            </ul>
          </div>
          <p className="font-mono text-[10px] tracking-[0.2em] text-[#4B5563]">
            © {new Date().getFullYear()} BLACKSTONE FX
          </p>
        </motion.div>
      </div>

      {/* form panel */}
      <div className="flex flex-1 items-center justify-center p-6">
        <div className="w-full max-w-md">
          <div className="mb-8 flex justify-center lg:hidden">
            <Link to="/" data-testid="login-mobile-logo-link">
              <LogoMark className="h-12 w-12" />
            </Link>
          </div>

          <motion.div initial={{ opacity: 0, y: 16, scale: 0.985 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ duration: 0.42, delay: 0.08, ease: "easeOut" }} whileHover={{ borderColor: "rgba(212,175,55,0.42)" }} className="glass-panel rounded-xl border border-[#D4AF37]/25 p-8" data-testid="login-card">
            <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-[#D4AF37]">SECURE GATEWAY</p>
            <h1 className="mt-3 font-heading text-2xl font-bold tracking-tight text-white">Sign in</h1>

            {/* role switcher */}
            <div className="mt-6 grid grid-cols-2 gap-2 rounded-lg border border-[#242B3A] bg-[#0D1117] p-1.5" data-testid="login-role-switcher">
              {(
                [
                  { id: "customer", label: "TRADER PORTAL", icon: User },
                  { id: "admin", label: "TERMINAL ADMIN", icon: Lock },
                ] as const
              ).map((tab) => {
                const Icon = tab.icon;
                const selected = mode === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setMode(tab.id)}
                    className={`flex items-center justify-center gap-2 rounded-md px-3 py-2.5 font-mono text-[10px] tracking-[0.16em] transition-colors duration-200 ${
                      selected ? "bg-[#2A2312] text-[#F5D77F]" : "text-[#6B7280] hover:text-[#9CA3AF]"
                    }`}
                    data-testid={`login-mode-${tab.id}`}
                  >
                    <Icon className="h-3.5 w-3.5" />
                    {tab.label}
                  </button>
                );
              })}
            </div>

            {mode === "customer" ? (
              <form className="mt-6 space-y-4" onSubmit={submitCustomer} data-testid="customer-login-form">
                <div>
                  <Label htmlFor="login-email" className="font-mono text-[10px] tracking-[0.18em] text-[#9CA3AF]">
                    EMAIL
                  </Label>
                  <Input
                    id="login-email"
                    type="email"
                    required
                    autoComplete="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="mt-1.5 border-[#242B3A] bg-[#0D1117]"
                    placeholder="you@example.com"
                    data-testid="login-email-input"
                  />
                </div>
                <div>
                  <Label htmlFor="login-password" className="font-mono text-[10px] tracking-[0.18em] text-[#9CA3AF]">
                    PASSWORD
                  </Label>
                  <Input
                    id="login-password"
                    type="password"
                    required
                    autoComplete="current-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="mt-1.5 border-[#242B3A] bg-[#0D1117]"
                    data-testid="login-password-input"
                  />
                </div>
                <Button type="submit" size="lg" className="w-full" disabled={login.isPending} data-testid="login-submit-button">
                  {login.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  SIGN IN TO PORTAL
                </Button>
              </form>
            ) : (
              <form className="mt-6 space-y-4" onSubmit={submitAdmin} data-testid="admin-login-form">
                <div>
                  <Label htmlFor="admin-username" className="font-mono text-[10px] tracking-[0.18em] text-[#9CA3AF]">
                    USERNAME
                  </Label>
                  <Input
                    id="admin-username"
                    required
                    autoComplete="username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="mt-1.5 border-[#242B3A] bg-[#0D1117]"
                    data-testid="login-username-input"
                  />
                </div>
                <div>
                  <Label htmlFor="admin-password" className="font-mono text-[10px] tracking-[0.18em] text-[#9CA3AF]">
                    PASSWORD
                  </Label>
                  <Input
                    id="admin-password"
                    type="password"
                    required
                    autoComplete="current-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="mt-1.5 border-[#242B3A] bg-[#0D1117]"
                    data-testid="login-admin-password-input"
                  />
                </div>
                <Button type="submit" size="lg" className="w-full" disabled={login.isPending} data-testid="login-admin-submit-button">
                  {login.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  OPEN CONTROL CENTER
                </Button>
              </form>
            )}

            <div className="mt-6 border-t border-[#242B3A] pt-5 text-center">
              <p className="text-xs text-[#6B7280]">
                No access yet?{" "}
                <Link to="/access" className="font-medium text-[#D4AF37] hover:text-[#F5D77F]" data-testid="login-to-access-link">
                  Join IB &amp; apply
                </Link>
              </p>
            </div>
          </div>

          <div className="mt-6 text-center">
            <Link
              to="/"
              className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-[#6B7280] transition-colors hover:text-[#D4AF37]"
              data-testid="login-back-home-link"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              BACK TO SYSTEM
            </Link>
          </motion.div>
        </div>
      </div>
      <Toaster />
    </div>
  );
}
