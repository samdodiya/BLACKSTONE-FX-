import { Link } from "react-router-dom";
import { Reveal } from "@/components/Reveal";

const SECTIONS = [
  {
    title: "1. Acceptance",
    body: "By accessing the BLACKSTONE FX platform or applying for EA access you agree to these terms. If you do not agree, do not use the platform.",
  },
  {
    title: "2. Access and eligibility",
    body: "Access to the BLACKSTONE EA is administered manually. An application must be submitted through the official IB referral, reviewed by an administrator, and approved before any license is issued. We may reject, suspend, revoke or decline to renew any license at our discretion.",
  },
  {
    title: "3. License binding",
    body: "Each license is bound to a single MT5 account number, broker and server combination, carries a license ID and an expiry date, and is validated server-side. The EA operates only when the license server confirms the binding and an ACTIVE status.",
  },
  {
    title: "4. Acceptable use",
    body: "You agree not to attempt to circumvent license validation, redistribute the compiled EX5, share portal credentials, or use the platform for any unlawful activity. Attempted circumvention may result in permanent revocation without refund.",
  },
  {
    title: "5. Distribution restrictions",
    body: "Customers receive only the compiled Blackstone_EA.ex5 artifact through the authorized download route. The MQ5 source code is proprietary and is never distributed under any circumstances.",
  },
  {
    title: "6. No warranty",
    body: "The platform and the EA are provided on an as-is basis without warranties of any kind. We do not warrant uninterrupted operation, compatibility with every broker environment, or fitness for your particular purpose.",
  },
  {
    title: "7. Limitation of liability",
    body: "To the maximum extent permitted by law, BLACKSTONE FX is not liable for trading losses, missed opportunities, data loss or consequential damages arising from the use of the platform or the EA.",
  },
  {
    title: "8. Changes",
    body: "These terms may be updated from time to time. Continued use of the platform after changes constitutes acceptance of the revised terms.",
  },
];

export default function Terms() {
  return (
    <div className="carbon-dots mx-auto max-w-4xl px-4 py-14 sm:px-6 lg:py-20">
      <Reveal>
        <p className="font-mono text-[11px] uppercase tracking-[0.28em] text-[#D4AF37]">LEGAL</p>
        <h1 className="mt-3 font-heading text-3xl font-bold tracking-tight text-white sm:text-4xl">
          TERMS OF SERVICE
        </h1>
        <p className="mt-4 text-sm text-[#6B7280]">
          Effective from first publication · BLACKSTONE FX — Automated Trading Technology
        </p>
      </Reveal>

      <div className="mt-10 space-y-5">
        {SECTIONS.map((section, i) => (
          <Reveal key={section.title} delay={i * 0.03}>
            <section className="border-l-2 border-[#D4AF37]/40 pl-5" data-testid={`terms-section-${i + 1}`}>
              <h2 className="font-heading text-base font-semibold tracking-tight text-white">{section.title}</h2>
              <p className="mt-2.5 text-sm leading-relaxed text-[#9CA3AF]">{section.body}</p>
            </section>
          </Reveal>
        ))}
      </div>

      <Reveal delay={0.1}>
        <p className="mt-10 rounded-lg border border-[#242B3A] bg-[#161B26] p-5 text-xs leading-relaxed text-[#6B7280]">
          Trading financial markets involves substantial risk. Past performance does not guarantee future
          results. BLACKSTONE FX does not guarantee profits.
        </p>
      </Reveal>
    </div>
  );
}
