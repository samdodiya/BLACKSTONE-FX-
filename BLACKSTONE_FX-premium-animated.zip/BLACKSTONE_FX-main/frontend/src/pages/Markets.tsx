import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Activity, Clock, Globe, Landmark } from "lucide-react";
import { apiGet } from "@/lib/api";
import type { MarketStatusResponse } from "@/lib/types";
import { TradingViewChart } from "@/components/trading/TradingViewChart";
import { Reveal } from "@/components/Reveal";

type SymbolKey = "XAUUSD" | "EURUSD" | "GBPUSD" | "USDJPY" | "US100";
type IntervalKey = "1m" | "5m" | "15m" | "1h" | "4h" | "D";

interface Instrument {
  tv: string;
  name: string;
  assetClass: string;
  quote: string;
  session: string;
  precision: string;
}

// TradingView feed symbols — display-only public widget, no market-data API involved.
const SYMBOLS: Record<SymbolKey, Instrument> = {
  XAUUSD: {
    tv: "OANDA:XAUUSD",
    name: "GOLD / US DOLLAR",
    assetClass: "Metals — Spot",
    quote: "USD",
    session: "24/5 continuous (indicative)",
    precision: "0.01",
  },
  EURUSD: {
    tv: "OANDA:EURUSD",
    name: "EURO / US DOLLAR",
    assetClass: "FX Major",
    quote: "USD",
    session: "24/5 continuous (indicative)",
    precision: "0.00001",
  },
  GBPUSD: {
    tv: "OANDA:GBPUSD",
    name: "BRITISH POUND / US DOLLAR",
    assetClass: "FX Major",
    quote: "USD",
    session: "24/5 continuous (indicative)",
    precision: "0.00001",
  },
  USDJPY: {
    tv: "OANDA:USDJPY",
    name: "US DOLLAR / JAPANESE YEN",
    assetClass: "FX Major",
    quote: "JPY",
    session: "24/5 continuous (indicative)",
    precision: "0.001",
  },
  US100: {
    tv: "OANDA:NAS100USD",
    name: "US TECH 100 INDEX",
    assetClass: "Index CFD",
    quote: "USD",
    session: "Cash + extended hours (indicative)",
    precision: "0.1",
  },
};

const TIMEFRAMES: { key: IntervalKey; label: string; tv: string }[] = [
  { key: "1m", label: "1M", tv: "1" },
  { key: "5m", label: "5M", tv: "5" },
  { key: "15m", label: "15M", tv: "15" },
  { key: "1h", label: "1H", tv: "60" },
  { key: "4h", label: "4H", tv: "240" },
  { key: "D", label: "1D", tv: "D" },
];

export default function Markets() {
  const [symbol, setSymbol] = useState<SymbolKey>("XAUUSD");
  const [interval, setInterval] = useState<IntervalKey>("15m");

  const { data: status } = useQuery({
    queryKey: ["market", "status"],
    queryFn: () => apiGet<MarketStatusResponse>("/market/status"),
    refetchInterval: 60_000,
  });

  const instrument = SYMBOLS[symbol];

  return (
    <div className="carbon-dots mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:py-16">
      <Reveal>
        <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
          <div>
            <p className="font-mono text-[11px] uppercase tracking-[0.28em] text-[#D4AF37]">
              INSTITUTIONAL TERMINAL
            </p>
            <h1 className="mt-3 font-heading text-3xl font-bold tracking-tight text-white sm:text-4xl">
              LIVE MARKETS
            </h1>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <span
              className={`flex items-center gap-2 rounded-full border px-3.5 py-1.5 font-mono text-[10px] tracking-[0.18em] ${
                status?.market_open
                  ? "border-[#10B981]/40 bg-[#06281E] text-[#34D399]"
                  : "border-[#F59E0B]/40 bg-[#2B210D] text-[#FBBF24]"
              }`}
              data-testid="market-status-badge"
            >
              <span className={`live-dot inline-block h-1.5 w-1.5 rounded-full ${status?.market_open ? "bg-[#34D399]" : "bg-[#FBBF24]"}`} />
              {status ? (status.market_open ? "MARKET OPEN" : "MARKET CLOSED") : "CHECKING STATUS…"}
            </span>
            <span className="flex items-center gap-2 font-mono text-[10px] tracking-[0.18em] text-[#6B7280]" data-testid="market-server-clock">
              <Clock className="h-3.5 w-3.5" />
              {status?.server_time_utc ?? "— UTC"}
            </span>
          </div>
        </div>
      </Reveal>

      {/* symbol selector */}
      <Reveal delay={0.05}>
        <div className="mt-8 flex flex-wrap gap-2" data-testid="symbol-selector">
          {(Object.keys(SYMBOLS) as SymbolKey[]).map((key) => (
            <button
              key={key}
              onClick={() => setSymbol(key)}
              className={`rounded-md border px-4 py-2 font-mono text-xs tracking-[0.14em] transition-all duration-200 ${
                symbol === key
                  ? "border-[#D4AF37]/60 bg-[#2A2312] text-[#F5D77F] shadow-[0_0_20px_rgba(212,175,55,0.15)]"
                  : "border-[#242B3A] bg-[#12161F] text-[#9CA3AF] hover:border-[#D4AF37]/40 hover:text-white"
              }`}
              data-testid={`symbol-select-${key.toLowerCase()}`}
            >
              {key}
            </button>
          ))}
        </div>
      </Reveal>

      {/* terminal: chart + info column */}
      <div className="mt-5 grid gap-5 lg:grid-cols-[1fr_320px]">
        <Reveal delay={0.08} className="min-w-0">
          <div className="overflow-hidden rounded-lg border border-[#242B3A] bg-[#0D1117]" data-testid="markets-chart-panel">
            <div className="flex items-center justify-between border-b border-[#242B3A] px-4 py-2.5">
              <div className="flex items-center gap-3">
                <span className="h-2 w-2 rotate-45 bg-[#D4AF37]" />
                <span className="font-mono text-xs font-semibold tracking-[0.14em] text-[#F5D77F]">{symbol}</span>
                <span className="hidden font-mono text-[10px] tracking-[0.14em] text-[#6B7280] sm:inline">
                  {instrument.tv}
                </span>
              </div>
              <span className="font-mono text-[10px] tracking-[0.14em] text-[#6B7280]">DATA: TRADINGVIEW</span>
            </div>

            <div className="flex flex-wrap gap-1.5 border-b border-[#242B3A] px-4 py-2" data-testid="timeframe-selector">
              {TIMEFRAMES.map((tf) => (
                <button
                  key={tf.key}
                  onClick={() => setInterval(tf.key)}
                  className={`rounded border px-2.5 py-1 font-mono text-[10px] tracking-[0.12em] transition-colors duration-150 ${
                    interval === tf.key
                      ? "border-[#D4AF37]/50 bg-[#2A2312] text-[#F5D77F]"
                      : "border-transparent text-[#6B7280] hover:text-[#D4AF37]"
                  }`}
                  data-testid={`timeframe-select-${tf.key.toLowerCase()}`}
                >
                  {tf.label}
                </button>
              ))}
            </div>

            <div className="p-2">
              <TradingViewChart symbol={instrument.tv} interval={TIMEFRAMES.find((t) => t.key === interval)!.tv} testId="tradingview-chart" />
            </div>
          </div>
        </Reveal>

        {/* right info rail */}
        <div className="flex flex-col gap-5">
          <Reveal delay={0.1}>
            <div className="rounded-lg border border-[#242B3A] bg-[#161B26] p-5" data-testid="instrument-info-card">
              <div className="flex items-center gap-2">
                <Landmark className="h-4 w-4 text-[#D4AF37]" />
                <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-[#D4AF37]">INSTRUMENT</p>
              </div>
              <p className="mt-3 font-heading text-lg font-semibold tracking-tight text-white">{instrument.name}</p>
              <dl className="mt-4 space-y-2.5 text-sm">
                {[
                  ["SYMBOL", symbol],
                  ["FEED", instrument.tv],
                  ["ASSET CLASS", instrument.assetClass],
                  ["QUOTE", instrument.quote],
                  ["TICK PRECISION", instrument.precision],
                  ["SESSION", instrument.session],
                ].map(([label, value]) => (
                  <div key={label} className="flex items-center justify-between gap-4 border-b border-[#242B3A]/60 pb-2 last:border-0">
                    <dt className="font-mono text-[10px] tracking-[0.16em] text-[#6B7280]">{label}</dt>
                    <dd className="text-right font-mono text-xs text-[#E6EDF3]">{value}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </Reveal>

          <Reveal delay={0.12}>
            <div className="rounded-lg border border-[#242B3A] bg-[#161B26] p-5" data-testid="market-session-card">
              <div className="flex items-center gap-2">
                <Globe className="h-4 w-4 text-[#D4AF37]" />
                <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-[#D4AF37]">SESSION STATUS</p>
              </div>
              <p className="mt-3 text-sm leading-relaxed text-[#9CA3AF]">
                {status?.next_event ?? "Session hours are indicative — confirm with your broker's server time."}
              </p>
              <p className="mt-3 font-mono text-[10px] leading-relaxed tracking-[0.1em] text-[#4B5563]">
                FX &amp; METALS: MON 00:00 → FRI 22:00 UTC · INDEX CFD SESSIONS VARY BY FEED
              </p>
            </div>
          </Reveal>

          <Reveal delay={0.14}>
            <div className="rounded-lg border border-[#D4AF37]/25 bg-[#12161F] p-5" data-testid="markets-note-card">
              <div className="flex items-center gap-2">
                <Activity className="h-4 w-4 text-[#D4AF37]" />
                <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-[#D4AF37]">TERMINAL NOTE</p>
              </div>
              <p className="mt-3 text-xs leading-relaxed text-[#9CA3AF]">
                Charts are provided by the public TradingView widget for market context. Broker-side pricing in
                MT5 may differ. Nothing on this page is investment advice or a performance representation.
              </p>
            </div>
          </Reveal>
        </div>
      </div>
    </div>
  );
}
