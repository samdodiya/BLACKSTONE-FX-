import { Activity, Cpu, Fingerprint, ShieldCheck } from "lucide-react";
import { LogoMark } from "@/components/Logo";

// Hero visual: a pure CSS/SVG "EA Mission Control" glass panel — crisp at any
// resolution, honest by construction (illustrative telemetry, never performance).
const STATUS_ROWS = [
  { icon: Cpu, label: "ENGINE STATE", value: "STANDBY", tone: "text-[#34D399]" },
  { icon: Fingerprint, label: "LICENSE", value: "ACCOUNT-BOUND", tone: "text-[#F5D77F]" },
  { icon: Activity, label: "MT5", value: "READY", tone: "text-[#34D399]" },
  { icon: ShieldCheck, label: "RISK GUARD", value: "ARMED", tone: "text-[#F5D77F]" },
];

const FEED = [
  { t: "12:00:04", s: "XAUUSD", a: "ORDER_FILLED", v: "0.02 LOT" },
  { t: "12:00:07", s: "XAUUSD", a: "RISK_CHECK", v: "PASS" },
  { t: "12:00:12", s: "BASKET", a: "SYNC", v: "OK" },
];

export function HeroPanel() {
  return (
    <div className="relative" data-testid="hero-panel">
      <div className="glass-panel gold-glow relative overflow-hidden rounded-xl border border-[#D4AF37]/25 p-6">
        <div className="flex items-center justify-between border-b border-[#242B3A] pb-4">
          <div className="flex items-center gap-3">
            <LogoMark className="h-8 w-8" />
            <div>
              <p className="font-heading text-sm font-bold tracking-[0.14em] text-white">BLACKSTONE EA</p>
              <p className="font-mono text-[10px] tracking-[0.2em] text-[#6B7280]">MISSION CONTROL · v1.2.0</p>
            </div>
          </div>
          <span className="flex items-center gap-2 rounded-full border border-[#D4AF37]/40 bg-[#2A2312] px-3 py-1 font-mono text-[10px] tracking-[0.2em] text-[#F5D77F]">
            <span className="live-dot inline-block h-1.5 w-1.5 rounded-full bg-[#D4AF37]" />
            LIVE
          </span>
        </div>

        <div className="grid grid-cols-2 gap-3 py-5">
          {STATUS_ROWS.map((row) => {
            const Icon = row.icon;
            return (
              <div key={row.label} className="hero-status-card rounded-md border border-[#242B3A] bg-[#0E121A]/80 p-3">
                <div className="flex items-center gap-2 text-[#6B7280]">
                  <Icon className="h-3.5 w-3.5" />
                  <span className="font-mono text-[9px] tracking-[0.2em]">{row.label}</span>
                </div>
                <p className={`mt-1.5 font-mono text-xs font-semibold tracking-[0.12em] ${row.tone}`}>{row.value}</p>
              </div>
            );
          })}
        </div>

        <div className="hero-chart-panel rounded-md border border-[#242B3A] bg-[#0D1117] p-4">
          <svg viewBox="0 0 300 80" className="h-20 w-full" aria-hidden="true">
            <defs>
              <linearGradient id="hero-spark" x1="0" y1="0" x2="300" y2="0" gradientUnits="userSpaceOnUse">
                <stop stopColor="#B8912B" />
                <stop offset="1" stopColor="#F5D77F" />
              </linearGradient>
              <linearGradient id="hero-spark-fill" x1="0" y1="0" x2="0" y2="1">
                <stop stopColor="#D4AF37" stopOpacity="0.25" />
                <stop offset="1" stopColor="#D4AF37" stopOpacity="0" />
              </linearGradient>
            </defs>
            {[16, 36, 56, 76].map((y) => (
              <line key={y} x1="0" y1={y} x2="300" y2={y} stroke="#1E2533" strokeWidth="1" />
            ))}
            <polygon
              points="0,62 20,55 40,58 60,48 80,50 100,40 120,44 140,34 160,38 180,28 200,32 220,22 240,26 260,16 280,20 300,10 300,80 0,80"
              fill="url(#hero-spark-fill)"
            />
            <polyline
              points="0,62 20,55 40,58 60,48 80,50 100,40 120,44 140,34 160,38 180,28 200,32 220,22 240,26 260,16 280,20 300,10"
              fill="none"
              stroke="url(#hero-spark)"
              strokeWidth="1.6"
            />
          </svg>
          <p className="mt-2 font-mono text-[9px] tracking-[0.18em] text-[#4B5563]">
            EXECUTION TELEMETRY — ILLUSTRATIVE
          </p>
        </div>

        <div className="mt-4 space-y-1.5">
          {FEED.map((row) => (
            <div key={row.t} className="flex items-center justify-between font-mono text-[10px] tracking-[0.1em]">
              <span className="text-[#4B5563]">{row.t} UTC</span>
              <span className="text-[#9CA3AF]">{row.s}</span>
              <span className="text-[#F5D77F]">{row.a}</span>
              <span className="text-[#34D399]">{row.v}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="absolute -bottom-4 -left-4 hidden rounded-md border border-[#D4AF37]/30 bg-[#12161F] px-4 py-2.5 shadow-[0_8px_32px_rgba(0,0,0,0.5)] sm:block">
        <p className="font-mono text-[9px] tracking-[0.2em] text-[#6B7280]">ACCOUNT-BOUND LICENSE</p>
        <p className="font-mono text-xs font-semibold tracking-[0.12em] text-[#F5D77F]">BSFX-A1B2-C3D4-E5F6</p>
      </div>
    </div>
  );
}
