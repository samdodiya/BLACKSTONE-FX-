// BLACKSTONE FX brand mark — original geometric faceted "B" monogram in a chamfered
// hexagon, 24k gold gradient stroke on an obsidian core.

export function LogoMark({ className = "h-9 w-9" }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true" data-testid="brand-logo-mark">
      <defs>
        <linearGradient id="bsfx-gold" x1="6" y1="6" x2="42" y2="42" gradientUnits="userSpaceOnUse">
          <stop stopColor="#F5D77F" />
          <stop offset="1" stopColor="#B8912B" />
        </linearGradient>
      </defs>
      <path
        d="M24 2 42 12.5v23L24 46 6 35.5v-23L24 2Z"
        stroke="url(#bsfx-gold)"
        strokeWidth="1.6"
        fill="#0B0D11"
        fillOpacity="0.65"
      />
      <path
        d="M17 14v20M17 14h10.5a5 5 0 0 1 0 10H17M17 24h12a5 5 0 0 1 0 10H17"
        stroke="url(#bsfx-gold)"
        strokeWidth="2.2"
        strokeLinecap="square"
        strokeLinejoin="miter"
      />
      <circle cx="24" cy="3.4" r="1.1" fill="#F5D77F" />
    </svg>
  );
}

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <span className="flex items-center gap-2.5">
      <LogoMark className="h-9 w-9" />
      {!compact && (
        <span className="font-heading text-sm font-extrabold uppercase leading-none tracking-[0.22em] text-white sm:text-base">
          Blackstone <span className="text-[#D4AF37]">FX</span>
        </span>
      )}
    </span>
  );
}
