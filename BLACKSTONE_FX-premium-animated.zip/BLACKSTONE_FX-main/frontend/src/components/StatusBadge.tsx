import { Badge } from "@/components/ui/badge";

// License / application status pills — obsidian-tinted chips with status-colored text.
const STYLES: Record<string, string> = {
  ACTIVE: "border-[#10B981]/40 bg-[#06281E] text-[#34D399]",
  PENDING: "border-[#F59E0B]/40 bg-[#2B210D] text-[#FBBF24]",
  APPROVED: "border-[#D4AF37]/40 bg-[#2A2312] text-[#F5D77F]",
  REJECTED: "border-[#EF4444]/40 bg-[#2B1115] text-[#F87171]",
  SUSPENDED: "border-[#F59E0B]/40 bg-[#2B1D0D] text-[#FB923C]",
  REVOKED: "border-[#EF4444]/40 bg-[#2B1115] text-[#F87171]",
  EXPIRED: "border-[#6B7280]/40 bg-[#1F2430] text-[#9CA3AF]",
  NONE: "border-[#6B7280]/40 bg-[#1F2430] text-[#9CA3AF]",
};

export function StatusBadge({ status, testId }: { status: string; testId?: string }) {
  const style = STYLES[status] ?? STYLES.NONE;
  return (
    <Badge
      variant="outline"
      className={`gap-1.5 border font-mono text-[10px] tracking-[0.14em] ${style}`}
      data-testid={testId ?? "status-badge"}
    >
      <span className="inline-block h-1.5 w-1.5 rounded-full bg-current" />
      {status}
    </Badge>
  );
}
