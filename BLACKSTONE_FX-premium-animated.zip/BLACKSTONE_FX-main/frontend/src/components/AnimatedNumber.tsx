import { useEffect, useRef } from "react";
import { animate, useInView } from "motion/react";

// Dashboard metric ticker: counts up from zero when scrolled into view.
export function AnimatedNumber({ value, testId }: { value: number; testId?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });

  useEffect(() => {
    if (!inView || !ref.current) return;
    const controls = animate(0, value, {
      duration: 0.9,
      ease: "easeOut",
      onUpdate: (v) => {
        if (ref.current) ref.current.textContent = Math.round(v).toLocaleString("en-US");
      },
    });
    return () => controls.stop();
  }, [inView, value]);

  return (
    <span ref={ref} data-testid={testId}>
      0
    </span>
  );
}
