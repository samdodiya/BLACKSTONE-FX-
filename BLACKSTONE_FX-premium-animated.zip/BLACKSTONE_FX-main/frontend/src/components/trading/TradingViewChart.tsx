import { useEffect, useRef } from "react";

// StrictMode-safe TradingView Advanced Chart embed (public widget — no API key).
// The widget is config-at-creation: the host is cleared and the loader re-injected
// whenever symbol/interval changes, so exactly one iframe ever exists.
declare global {
  interface Window {
    TradingView?: unknown;
  }
}

const SCRIPT_SRC = "https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js";

interface TradingViewChartProps {
  symbol: string; // TradingView "EXCHANGE:SYMBOL" notation
  interval: string; // TradingView interval code ("1","5","15","60","240","D")
  testId?: string;
}

export function TradingViewChart({ symbol, interval, testId }: TradingViewChartProps) {
  const host = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const root = host.current;
    if (!root) return;

    root.replaceChildren();

    const container = document.createElement("div");
    container.className = "tradingview-widget-container";
    container.style.cssText = "height:100%;width:100%";

    const widget = document.createElement("div");
    widget.className = "tradingview-widget-container__widget";
    widget.style.cssText = "height:100%;width:100%";

    const script = document.createElement("script");
    script.type = "text/javascript";
    script.src = SCRIPT_SRC;
    script.async = true;
    // The official embed loader reads the JSON payload following the script tag.
    script.text = JSON.stringify({
      autosize: true,
      symbol,
      interval,
      timezone: "Etc/UTC",
      theme: "dark",
      style: "1",
      locale: "en",
      allow_symbol_change: false,
      hide_top_toolbar: false,
      hide_legend: false,
      save_image: false,
      calendar: false,
      support_host: "https://www.tradingview.com",
    });

    container.append(widget, script);
    root.append(container);

    return () => {
      root.replaceChildren();
    };
  }, [symbol, interval]);

  return <div ref={host} className="h-[560px] w-full min-w-0 sm:h-[620px]" data-testid={testId} />;
}
