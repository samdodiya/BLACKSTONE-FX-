// Instrument ribbon — symbol identities (no fabricated prices; live pricing is
// rendered by the TradingView chart itself on the terminal).

const ITEMS = [
  { symbol: "XAUUSD", name: "GOLD / USD", tag: "METALS" },
  { symbol: "EURUSD", name: "EURO / USD", tag: "FX MAJOR" },
  { symbol: "GBPUSD", name: "POUND / USD", tag: "FX MAJOR" },
  { symbol: "USDJPY", name: "USD / YEN", tag: "FX MAJOR" },
  { symbol: "US100", name: "US TECH 100", tag: "INDEX CFD" },
];

export function TickerRibbon() {
  const doubled = [...ITEMS, ...ITEMS, ...ITEMS];
  return (
    <div
      className="ticker-ribbon overflow-hidden border-y border-[#242B3A] bg-[#0E121A] py-3"
      data-testid="ticker-ribbon"
      aria-label="Supported instruments"
    >
      <div className="ticker-track flex w-max items-center gap-12 px-6">
        {doubled.map((item, i) => (
          <div key={`${item.symbol}-${i}`} className="flex items-center gap-3 font-mono text-[11px] tracking-[0.15em]">
            <span className="inline-block h-1.5 w-1.5 rotate-45 bg-[#D4AF37]" />
            <span className="font-semibold text-[#F5D77F]">{item.symbol}</span>
            <span className="text-[#9CA3AF]">{item.name}</span>
            <span className="text-[#4B5563]">{item.tag}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
