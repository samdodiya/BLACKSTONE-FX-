import { useState, type ReactNode } from "react";
import { motion } from "motion/react";
import { Link } from "react-router-dom";
import { LogOut, Menu, type LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Logo } from "@/components/Logo";

export interface ShellNavItem {
  id: string;
  label: string;
  icon: LucideIcon;
}

interface DashboardShellProps {
  title: string;
  subtitle: string;
  items: ShellNavItem[];
  active: string;
  onNavigate: (id: string) => void;
  onLogout: () => void;
  children: ReactNode;
  testPrefix: string;
}

// Shared dark sidebar shell for the Customer Portal and the Admin Control Center.
export function DashboardShell({
  title,
  subtitle,
  items,
  active,
  onNavigate,
  onLogout,
  children,
  testPrefix,
}: DashboardShellProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const body = (
    <div className="flex h-full flex-col gap-7 p-5">
      <Link to="/" className="shrink-0" data-testid={`${testPrefix}-sidebar-logo-link`}>
        <Logo />
      </Link>
      <div>
        <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-[#D4AF37]">{title}</p>
        <p className="mt-1 text-xs text-[#6B7280]">{subtitle}</p>
      </div>
      <nav className="flex flex-1 flex-col gap-1" aria-label="Dashboard">
        {items.map((item) => {
          const Icon = item.icon;
          const selected = item.id === active;
          return (
            <button
              key={item.id}
              onClick={() => {
                onNavigate(item.id);
                setMobileOpen(false);
              }}
              className={`flex items-center gap-3 rounded-md px-3 py-2.5 text-left text-sm transition-colors duration-200 ${
                selected
                  ? "border border-[#D4AF37]/40 bg-[#2A2312] text-[#F5D77F]"
                  : "border border-transparent text-[#9CA3AF] hover:bg-[#161B26] hover:text-white"
              }`}
              data-testid={`${testPrefix}-nav-${item.id}`}
            >
              <Icon className="h-4 w-4 shrink-0" />
              {item.label}
            </button>
          );
        })}
      </nav>
      <Button
        variant="outline"
        className="justify-start gap-3 border-[#242B3A] text-[#9CA3AF] hover:border-[#EF4444]/40 hover:text-[#F87171]"
        onClick={onLogout}
        data-testid={`${testPrefix}-logout-button`}
      >
        <LogOut className="h-4 w-4" />
        Logout
      </Button>
    </div>
  );

  return (
    <div className="flex min-h-svh bg-[#0B0D11] text-[#F3F4F6]" data-testid={`${testPrefix}-shell`}>
      <motion.aside initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.38, ease: "easeOut" }} className="hidden w-64 shrink-0 border-r border-[#242B3A] bg-[#0E121A] md:block">
        <div className="sticky top-0 h-svh">{body}</div>
      </motion.aside>
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-40 flex items-center justify-between border-b border-[#242B3A] bg-[#0B0D11]/90 px-4 py-3 backdrop-blur-xl md:hidden">
          <Logo />
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger
              className="inline-flex h-10 w-10 items-center justify-center rounded-md border border-[#242B3A] text-[#C7CCD6] transition-colors hover:border-[#D4AF37]/50 hover:text-[#D4AF37]"
              aria-label="Open dashboard menu"
              data-testid={`${testPrefix}-mobile-menu-button`}
            >
              <Menu className="h-5 w-5" />
            </SheetTrigger>
            <SheetContent side="right" className="w-80 border-[#242B3A] bg-[#0E121A] p-0">
              <SheetTitle className="sr-only">Dashboard navigation</SheetTitle>
              {body}
            </SheetContent>
          </Sheet>
        </header>
        <main className="dashboard-content min-w-0 flex-1 p-4 sm:p-6 md:p-8"><motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.32, ease: "easeOut" }}>{children}</motion.div></main>
      </div>
    </div>
  );
}
