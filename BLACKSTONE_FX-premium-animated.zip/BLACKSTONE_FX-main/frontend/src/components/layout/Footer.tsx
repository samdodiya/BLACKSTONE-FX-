import { Link } from "react-router-dom";
import { Logo } from "@/components/Logo";

const SYSTEM_LINKS = [
  { to: "/", label: "System" },
  { to: "/markets", label: "Live Markets" },
  { to: "/ea-intelligence", label: "EA Intelligence" },
  { to: "/access", label: "Access" },
  { to: "/portal", label: "Client Portal" },
  { to: "/admin", label: "Admin" },
];

const LEGAL_LINKS = [
  { to: "/risk-disclosure", label: "Risk Disclosure" },
  { to: "/terms", label: "Terms" },
  { to: "/privacy", label: "Privacy" },
];

export function Footer() {
  return (
    <footer className="border-t border-[#242B3A] bg-[#0E121A]" data-testid="site-footer">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div className="grid gap-10 md:grid-cols-12">
          <div className="md:col-span-5">
            <Logo />
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-[#9CA3AF]">
              Automated Trading Technology. A premium MT5 ecosystem built around structured execution,
              configurable risk controls and account-bound EA access.
            </p>
            <a
              href="mailto:contact@blackstonefx.example"
              className="mt-4 inline-block font-mono text-xs tracking-[0.14em] text-[#D4AF37] hover:text-[#F5D77F]"
              data-testid="footer-contact-link"
            >
              CONTACT@BLACKSTONEFX.EXAMPLE
            </a>
          </div>

          <div className="md:col-span-3">
            <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-[#D4AF37]">Platform</p>
            <ul className="mt-4 space-y-2.5">
              {SYSTEM_LINKS.map((link) => (
                <li key={link.to}>
                  <Link to={link.to} className="text-sm text-[#9CA3AF] transition-colors hover:text-[#D4AF37]" data-testid={`footer-link-${link.label.toLowerCase().replace(/\s+/g, "-")}`}>
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-4">
            <p className="font-mono text-[10px] uppercase tracking-[0.25em] text-[#D4AF37]">Legal</p>
            <ul className="mt-4 space-y-2.5">
              {LEGAL_LINKS.map((link) => (
                <li key={link.to}>
                  <Link to={link.to} className="text-sm text-[#9CA3AF] transition-colors hover:text-[#D4AF37]" data-testid={`footer-link-${link.label.toLowerCase().replace(/\s+/g, "-")}`}>
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 rounded-md border border-[#D4AF37]/25 bg-[#12161F] p-4">
          <p className="text-xs leading-relaxed text-[#9CA3AF]">
            <span className="font-mono uppercase tracking-[0.14em] text-[#D4AF37]">Risk disclosure — </span>
            Trading financial markets involves substantial risk. Past performance does not guarantee future
            results. BLACKSTONE FX does not guarantee profits. Automated systems can incur losses as well as
            gains; never trade with capital you cannot afford to lose.
          </p>
        </div>

        <div className="mt-8 flex flex-col items-start justify-between gap-3 border-t border-[#242B3A] pt-6 sm:flex-row sm:items-center">
          <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-[#6B7280]">
            © {new Date().getFullYear()} BLACKSTONE FX — All rights reserved
          </p>
          <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-[#6B7280]">
            Chart data by TradingView · MT5 is a trademark of MetaQuotes Ltd
          </p>
        </div>
      </div>
    </footer>
  );
}
