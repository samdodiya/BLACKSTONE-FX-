import { useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { Menu, X } from "lucide-react";
import { buttonVariants } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Logo, LogoMark } from "@/components/Logo";

export const NAV_LINKS = [
  { to: "/", label: "System" },
  { to: "/markets", label: "Live Markets" },
  { to: "/ea-intelligence", label: "EA Intelligence" },
  { to: "/access", label: "Access" },
  { to: "/portal", label: "Client Portal" },
  { to: "/admin", label: "Admin" },
];

export function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);

  const linkClass = ({ isActive }: { isActive: boolean }) =>
    `px-1 py-2 font-mono text-[11px] uppercase tracking-[0.18em] transition-colors duration-200 hover:text-[#D4AF37] ${
      isActive ? "text-[#D4AF37]" : "text-[#C7CCD6]"
    }`;

  return (
    <header
      className="sticky top-0 z-50 w-full border-b border-[#D4AF37]/20 bg-[#0B0D11]/85 backdrop-blur-xl backdrop-saturate-150"
      data-testid="site-navbar"
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
        <Link to="/" className="shrink-0 transition-opacity hover:opacity-85" data-testid="nav-logo-link">
          <Logo />
        </Link>

        <nav className="hidden items-center gap-6 lg:flex" aria-label="Primary">
          {NAV_LINKS.map((link) => (
            <NavLink key={link.to} to={link.to} className={linkClass} end={link.to === "/"} data-testid={`nav-link-${link.label.toLowerCase().replace(/\s+/g, "-")}`}>
              {link.label}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <Link
            to="/access"
            className={`${buttonVariants({ size: "sm" })} hidden sm:inline-flex`}
            data-testid="nav-get-access-button"
          >
            GET ACCESS
          </Link>

          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger
              className="inline-flex h-10 w-10 items-center justify-center rounded-md border border-[#242B3A] text-[#C7CCD6] transition-colors hover:border-[#D4AF37]/50 hover:text-[#D4AF37] lg:hidden"
              aria-label="Open navigation menu"
              data-testid="nav-mobile-menu-button"
            >
              {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </SheetTrigger>
            <SheetContent side="right" className="w-80 border-[#242B3A] bg-[#0E121A] p-6">
              <SheetTitle className="sr-only">Navigation</SheetTitle>
              <div className="flex h-full flex-col gap-8">
                <Logo />
                <nav className="flex flex-col gap-1" aria-label="Mobile">
                  {NAV_LINKS.map((link) => (
                    <NavLink
                      key={link.to}
                      to={link.to}
                      end={link.to === "/"}
                      onClick={() => setMobileOpen(false)}
                      className={({ isActive }) =>
                        `rounded-md px-3 py-2.5 font-mono text-xs uppercase tracking-[0.18em] transition-colors ${
                          isActive
                            ? "bg-[#2A2312] text-[#F5D77F]"
                            : "text-[#9CA3AF] hover:bg-[#161B26] hover:text-[#D4AF37]"
                        }`
                      }
                      data-testid={`nav-mobile-link-${link.label.toLowerCase().replace(/\s+/g, "-")}`}
                    >
                      {link.label}
                    </NavLink>
                  ))}
                </nav>
                <Link
                  to="/access"
                  onClick={() => setMobileOpen(false)}
                  className={`${buttonVariants({ size: "sm" })} mt-auto w-full`}
                  data-testid="nav-mobile-get-access-button"
                >
                  GET ACCESS
                </Link>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>

      {/* thin gold baseline accent */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-[#D4AF37]/45 to-transparent" />
      <LogoMark className="hidden" />
    </header>
  );
}
