import type { ReactNode } from "react";
import { motion } from "motion/react";

// Scroll-triggered reveal: subtle fade + slide-up, once. Respects reduced-motion
// via the user's OS setting handled by motion's default behavior.
interface RevealProps {
  children: ReactNode;
  delay?: number;
  className?: string;
  testId?: string;
}

export function Reveal({ children, delay = 0, className, testId }: RevealProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.35, ease: "easeOut", delay }}
      className={className}
      data-testid={testId}
    >
      {children}
    </motion.div>
  );
}
