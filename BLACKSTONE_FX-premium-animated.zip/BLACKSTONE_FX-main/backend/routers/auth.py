"""Auth routes: admin login, customer login, logout, session identity."""

from fastapi import APIRouter, Depends, HTTPException, Response
from starlette.requests import Request

from lib.audit import write_audit
from lib.db import db
from lib.ratelimit import rate_limit
from lib.security import (
    create_session,
    destroy_session,
    get_current_identity,
    verify_password,
)
from models.schemas import AdminLoginRequest, CustomerLoginRequest, SessionIdentity

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/admin/login", response_model=SessionIdentity)
async def admin_login(
    body: AdminLoginRequest,
    response: Response,
    _rl: None = Depends(rate_limit("admin-login", limit=10, window_seconds=60)),
) -> SessionIdentity:
    username = body.username.strip().lower()
    admin = await db.admin_users.find_one({"username": username})
    if not admin or not verify_password(body.password, admin["password_hash"]):
        await write_audit(actor=username, action="ADMIN_LOGIN_FAILED", details="Invalid admin credentials")
        raise HTTPException(status_code=401, detail="Invalid administrator credentials.")
    await create_session(response, sub=admin["id"], role="admin")
    await write_audit(actor=username, action="ADMIN_LOGIN", details="Administrator signed in")
    return SessionIdentity(role="admin", id=admin["id"], username=admin.get("username"))


@router.post("/customer/login", response_model=SessionIdentity)
async def customer_login(
    body: CustomerLoginRequest,
    response: Response,
    _rl: None = Depends(rate_limit("customer-login", limit=10, window_seconds=60)),
) -> SessionIdentity:
    email = body.email.lower()
    user = await db.users.find_one({"email": email})
    if not user or not verify_password(body.password, user["password_hash"]):
        await write_audit(actor=email, action="CUSTOMER_LOGIN_FAILED", details="Invalid customer credentials", target_email=email)
        raise HTTPException(status_code=401, detail="Invalid email or password.")
    await create_session(response, sub=user["id"], role="customer")
    await write_audit(actor=email, action="CUSTOMER_LOGIN", details="Customer signed in", target_email=email)
    return SessionIdentity(role="customer", id=user["id"], full_name=user.get("full_name"), email=email)


@router.post("/logout")
async def logout(request: Request, response: Response) -> dict:
    await destroy_session(request, response)
    return {"ok": True}


@router.get("/me", response_model=SessionIdentity)
async def me(identity: SessionIdentity = Depends(get_current_identity)) -> SessionIdentity:
    return identity
