"""Market terminal support: server-anchored UTC clock and FX session status so the
Live Markets page never relies on client-side date math."""

from datetime import datetime, timezone

from fastapi import APIRouter

from models.schemas import MarketStatusResponse

router = APIRouter(tags=["markets"])


def _fx_session_state(now: datetime) -> tuple[bool, str]:
    """Indicative FX/metals week: opens Mon 00:00 UTC, closes Fri 22:00 UTC,
    reopens Sun 22:00 UTC. Index CFD sessions differ slightly — labelled indicative."""
    weekday = now.weekday()  # Mon=0 ... Sun=6
    if weekday == 5:  # Saturday
        return False, "Market closed — reopens Sunday 22:00 UTC"
    if weekday == 6 and now.hour < 22:
        return False, "Market closed — reopens today 22:00 UTC"
    if weekday == 4 and now.hour >= 22:
        return False, "Market closed — reopens Sunday 22:00 UTC"
    return True, "Market closes Friday 22:00 UTC"


@router.get("/market/status", response_model=MarketStatusResponse)
async def market_status() -> MarketStatusResponse:
    now = datetime.now(timezone.utc)
    market_open, next_event = _fx_session_state(now)
    return MarketStatusResponse(
        server_time_utc=now.strftime("%Y-%m-%d %H:%M:%S UTC"),
        market_open=market_open,
        next_event=next_event,
    )
