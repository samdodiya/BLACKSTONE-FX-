"""Customer portal API: the signed-in customer's own profile + license. A customer
can only ever read their own record — server-side authorization, no client trust."""

from fastapi import APIRouter, Depends, HTTPException

from lib.db import db
from lib.licensing import license_row_from_doc, user_row_from_doc
from lib.security import require_customer
from models.schemas import CustomerDetail

router = APIRouter(tags=["customer"])


@router.get("/customer/me", response_model=CustomerDetail)
async def customer_me(identity=Depends(require_customer)) -> CustomerDetail:
    doc = await db.users.find_one({"id": identity.id}, {"password_hash": 0})
    if not doc:
        raise HTTPException(status_code=404, detail="Customer record not found.")
    license_doc = await db.licenses.find_one({"user_id": doc["id"]})
    return CustomerDetail(
        user=user_row_from_doc(doc),
        license=license_row_from_doc(license_doc) if license_doc else None,
    )
