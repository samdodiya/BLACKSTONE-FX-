"""IB registration: creates a PENDING application bound to MT5 account / broker /
server. Admin approval (Control Center) is the only path to an ACTIVE license."""

import os
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException

from lib.audit import write_audit
from lib.db import db
from lib.ratelimit import rate_limit
from lib.security import hash_password
from models.schemas import RegisterResponse, RegistrationRequest

router = APIRouter(tags=["registration"])


@router.post("/register", response_model=RegisterResponse, status_code=201)
async def register(
    body: RegistrationRequest,
    _rl: None = Depends(rate_limit("register", limit=8, window_seconds=600)),
) -> RegisterResponse:
    email = body.email.lower()
    if await db.users.find_one({"email": email}):
        raise HTTPException(status_code=409, detail="An application with this email already exists.")
    if await db.users.find_one({"mt5_account": body.mt5_account}):
        raise HTTPException(status_code=409, detail="This MT5 account number is already registered.")

    now = datetime.now(timezone.utc)
    user = {
        "id": str(uuid.uuid4()),
        "full_name": body.full_name.strip(),
        "email": email,
        "phone": body.phone.strip(),
        "mt5_account": body.mt5_account,
        "broker": body.broker.strip(),
        "mt5_server": body.mt5_server.strip(),
        "password_hash": hash_password(body.password),
        "ib_status": "PENDING",
        "license_status": "PENDING",
        "license_id": None,
        "activation_date": None,
        "expiry_date": None,
        "ea_version": None,
        "created_at": now,
    }
    try:
        await db.users.insert_one(user)
    except Exception:
        # unique index race (concurrent duplicate submission)
        raise HTTPException(status_code=409, detail="Duplicate application — email or MT5 account already registered.")

    await db.orders.insert_one(
        {
            "id": str(uuid.uuid4()),
            "order_id": "ORD-" + uuid.uuid4().hex[:8].upper(),
            "user_id": user["id"],
            "user_email": email,
            "order_type": "IB_REGISTRATION",
            "description": f"IB application submitted via referral {os.environ.get('IB_REFERRAL_CODE', 'TRI3lX2K')}",
            "created_at": now,
        }
    )
    await write_audit(
        actor=email,
        action="REGISTRATION_SUBMITTED",
        target_email=email,
        details=f"MT5 {body.mt5_account} @ {body.broker.strip()} / {body.mt5_server.strip()}",
    )
    return RegisterResponse(ok=True, status="PENDING", user_id=user["id"])
