"""License server API — the endpoints the BLACKSTONE EA and the gated download
route talk to. The EA is allowed to operate ONLY when the server confirms:
  - a license exists for the MT5 account,
  - broker and server match the approved binding,
  - license status is ACTIVE and not expired,
  - the customer's IB application is APPROVED.
The compiled EX5 is served from the server-side private directory — the MQ5
source is NEVER reachable through any route."""

import os
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import FileResponse

from lib.audit import write_audit
from lib.db import db
from lib.licensing import effective_license_status, to_aware
from lib.ratelimit import rate_limit
from lib.security import get_current_identity
from models.schemas import LicenseCheckResponse

router = APIRouter(tags=["license"])

# Server-side private storage — outside the frontend public directory, never static-served.
EA_FILE = Path(__file__).resolve().parent.parent / "private" / "Blackstone_EA.ex5"


@router.get("/license/check", response_model=LicenseCheckResponse)
async def license_check(
    mt5_account: str = Query(min_length=4, max_length=20),
    broker: str = Query(min_length=2, max_length=80),
    mt5_server: str = Query(min_length=2, max_length=120),
    _rl: None = Depends(rate_limit("license-check", limit=90, window_seconds=60)),
) -> LicenseCheckResponse:
    """EA-facing validation: account + broker + server binding, status and expiry."""
    license_doc = await db.licenses.find_one({"mt5_account": mt5_account.strip()})
    if not license_doc:
        return LicenseCheckResponse(allowed=False, reason="LICENSE_NOT_FOUND")

    binding_ok = (
        license_doc.get("broker", "").strip().upper() == broker.strip().upper()
        and license_doc.get("mt5_server", "").strip().upper() == mt5_server.strip().upper()
    )
    if not binding_ok:
        return LicenseCheckResponse(
            allowed=False,
            reason="BINDING_MISMATCH",
            license_id=license_doc.get("license_id"),
            status=license_doc.get("status"),
            expiry_date=license_doc.get("expiry_date"),
        )

    user = await db.users.find_one({"id": license_doc.get("user_id")})
    if not user or user.get("ib_status") != "APPROVED":
        return LicenseCheckResponse(
            allowed=False,
            reason="IB_NOT_APPROVED",
            license_id=license_doc.get("license_id"),
            status=license_doc.get("status"),
            expiry_date=license_doc.get("expiry_date"),
        )

    status = effective_license_status(license_doc.get("status", "NONE"), license_doc.get("expiry_date"))
    if status != "ACTIVE":
        return LicenseCheckResponse(
            allowed=False,
            reason=f"LICENSE_{status}",
            license_id=license_doc.get("license_id"),
            status=status,
            expiry_date=license_doc.get("expiry_date"),
        )

    expiry = license_doc.get("expiry_date")
    return LicenseCheckResponse(
        allowed=True,
        reason="LICENSE_ACTIVE",
        license_id=license_doc.get("license_id"),
        status="ACTIVE",
        expiry_date=expiry,
    )


@router.get("/ea/download")
async def ea_download(identity=Depends(get_current_identity)):
    """Gated EX5 distribution.

    - Administrators may pull the artifact for verification/distribution.
    - Customers may download ONLY while their license is ACTIVE (not expired),
      their IB application is APPROVED, and the binding matches the approved record.
    - The MQ5 source is never served — it does not exist anywhere near a route.
    """
    if identity.role == "admin":
        return _file_response()

    if identity.role != "customer":
        raise HTTPException(status_code=403, detail="Customer session required for EA download.")

    user = await db.users.find_one({"id": identity.id})
    if not user:
        raise HTTPException(status_code=404, detail="Customer record not found.")

    license_doc = await db.licenses.find_one({"user_id": user["id"]})
    status = effective_license_status(
        (license_doc or {}).get("status", "NONE"), (license_doc or {}).get("expiry_date")
    )
    binding_ok = (
        license_doc is not None
        and license_doc.get("mt5_account") == user.get("mt5_account")
        and license_doc.get("broker", "").strip().upper() == user.get("broker", "").strip().upper()
        and license_doc.get("mt5_server", "").strip().upper() == user.get("mt5_server", "").strip().upper()
    )

    if user.get("ib_status") != "APPROVED" or status != "ACTIVE" or not binding_ok:
        await write_audit(
            actor=user["email"],
            action="EA_DOWNLOAD_DENIED",
            target_email=user["email"],
            details=f"status={status} ib={user.get('ib_status')} binding_ok={binding_ok}",
        )
        raise HTTPException(
            status_code=403,
            detail=f"EA download unavailable — license status: {status}. Contact support if you believe this is an error.",
        )

    await write_audit(
        actor=user["email"],
        action="EA_DOWNLOAD",
        target_email=user["email"],
        details=f"license={license_doc.get('license_id')} ea_version={license_doc.get('ea_version')}",
    )
    return _file_response()


def _file_response() -> FileResponse:
    if not EA_FILE.exists():
        raise HTTPException(status_code=503, detail="EA artifact is not available. Contact the platform administrator.")
    return FileResponse(
        path=EA_FILE,
        media_type="application/octet-stream",
        filename="Blackstone_EA.ex5",
        headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"},
    )


def _unused() -> Optional[datetime]:  # keeps datetime import meaningful for typing tools
    return datetime.now(timezone.utc)
