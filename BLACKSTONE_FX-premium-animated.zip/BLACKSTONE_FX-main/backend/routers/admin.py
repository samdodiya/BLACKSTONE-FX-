"""Admin Control Center API — protected by the admin session guard. Every mutating
action is confirmed server-side, written to the licenses collection (the binding
record the EA validates against) and appended to the audit trail."""

import calendar
import os
import secrets
import uuid
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException

from lib.audit import write_audit
from lib.db import db
from lib.dates import add_months
from lib.licensing import license_row_from_doc, user_row_from_doc
from lib.security import require_admin
from models.schemas import (
    ActionResponse,
    AdminStats,
    AuditLogEntry,
    EaInfo,
    ExtendRequest,
    LicenseRecord,
    OrderRow,
    PlatformSettings,
    UserDetail,
    UserRow,
)

router = APIRouter(prefix="/admin", tags=["admin"])

EA_FILE = Path(__file__).resolve().parent.parent / "private" / "Blackstone_EA.ex5"


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _new_license_id() -> str:
    return "BSFX-" + "-".join(secrets.token_hex(2).upper() for _ in range(3))


async def _load_user(user_id: str) -> dict:
    doc = await db.users.find_one({"id": user_id}, {"password_hash": 0})
    if not doc:
        raise HTTPException(status_code=404, detail="User not found.")
    return doc


async def _sync_license_status(user_id: str, status: str) -> None:
    await db.licenses.update_one({"user_id": user_id}, {"$set": {"status": status}})
    await db.users.update_one({"id": user_id}, {"$set": {"license_status": status}})


@router.get("/stats", response_model=AdminStats)
async def admin_stats(_admin=Depends(require_admin)) -> AdminStats:
    now = _now()
    total_users = await db.users.count_documents({})
    pending = await db.users.count_documents({"ib_status": "PENDING"})
    total_licenses = await db.licenses.count_documents({})
    revoked = await db.licenses.count_documents({"status": "REVOKED"})
    orders = await db.orders.count_documents({})
    active = 0
    async for lic in db.licenses.find({"status": "ACTIVE"}, {"expiry_date": 1}):
        expiry = lic.get("expiry_date")
        if expiry is None or expiry.replace(tzinfo=timezone.utc) > now:
            active += 1
    return AdminStats(
        total_users=total_users,
        pending_applications=pending,
        active_licenses=active,
        revoked_licenses=revoked,
        total_licenses=total_licenses,
        orders=orders,
        settings=PlatformSettings(
            ea_version=os.environ.get("EA_VERSION", "1.2.0"),
            license_validity_months=int(os.environ.get("LICENSE_VALIDITY_MONTHS", "12")),
            session_ttl_hours=int(os.environ.get("SESSION_TTL_HOURS", "12")),
        ),
    )


@router.get("/users", response_model=list[UserRow])
async def admin_users(_admin=Depends(require_admin)) -> list[UserRow]:
    docs = await db.users.find({}, {"password_hash": 0}).sort("created_at", -1).to_list(1000)
    return [user_row_from_doc(doc) for doc in docs]


@router.get("/users/{user_id}", response_model=UserDetail)
async def admin_user_detail(user_id: str, _admin=Depends(require_admin)) -> UserDetail:
    doc = await _load_user(user_id)
    license_doc = await db.licenses.find_one({"user_id": user_id})
    logs = await db.audit_logs.find({"target_email": doc["email"]}).sort("created_at", -1).to_list(50)
    return UserDetail(
        user=user_row_from_doc(doc),
        license=license_row_from_doc(license_doc) if license_doc else None,
        logs=[AuditLogEntry(**log) for log in logs],
    )


@router.post("/users/{user_id}/approve", response_model=ActionResponse)
async def approve_user(user_id: str, admin=Depends(require_admin)) -> ActionResponse:
    doc = await _load_user(user_id)
    now = _now()
    months = int(os.environ.get("LICENSE_VALIDITY_MONTHS", "12"))
    license_id = doc.get("license_id") or _new_license_id()
    expiry = add_months(now, months)
    ea_version = os.environ.get("EA_VERSION", "1.2.0")

    await db.users.update_one(
        {"id": user_id},
        {"$set": {
            "ib_status": "APPROVED",
            "license_status": "ACTIVE",
            "license_id": license_id,
            "activation_date": now,
            "expiry_date": expiry,
            "ea_version": ea_version,
        }},
    )
    await db.licenses.update_one(
        {"user_id": user_id},
        {"$set": {
            "license_id": license_id,
            "email": doc["email"],
            "mt5_account": doc["mt5_account"],
            "broker": doc["broker"],
            "mt5_server": doc["mt5_server"],
            "status": "ACTIVE",
            "activation_date": now,
            "expiry_date": expiry,
            "ea_version": ea_version,
        }, "$setOnInsert": {"id": str(uuid.uuid4()), "user_id": user_id, "created_at": now}},
        upsert=True,
    )
    await db.orders.insert_one({
        "id": str(uuid.uuid4()),
        "order_id": "ORD-" + secrets.token_hex(4).upper(),
        "user_id": user_id,
        "user_email": doc["email"],
        "order_type": "EA_LICENSE",
        "description": f"License {license_id} activated for MT5 {doc['mt5_account']} ({doc['broker']})",
        "created_at": now,
    })
    await write_audit(
        actor=admin.username or "admin",
        action="APPLICATION_APPROVED",
        target_email=doc["email"],
        details=f"IB approved · license {license_id} ACTIVE until {expiry:%Y-%m-%d} · EX5 download enabled",
    )
    return ActionResponse(ok=True, user=user_row_from_doc(await _load_user(user_id)))


@router.post("/users/{user_id}/reject", response_model=ActionResponse)
async def reject_user(user_id: str, admin=Depends(require_admin)) -> ActionResponse:
    doc = await _load_user(user_id)
    if doc.get("ib_status") == "APPROVED":
        raise HTTPException(status_code=409, detail="Approved customers cannot be rejected — revoke the license instead.")
    await db.users.update_one({"id": user_id}, {"$set": {"ib_status": "REJECTED", "license_status": "NONE"}})
    await _sync_license_status(user_id, "NONE")
    await write_audit(
        actor=admin.username or "admin",
        action="APPLICATION_REJECTED",
        target_email=doc["email"],
        details="IB application rejected · no license issued",
    )
    return ActionResponse(ok=True, user=user_row_from_doc(await _load_user(user_id)))


@router.post("/users/{user_id}/revoke", response_model=ActionResponse)
async def revoke_user(user_id: str, admin=Depends(require_admin)) -> ActionResponse:
    doc = await _load_user(user_id)
    await _sync_license_status(user_id, "REVOKED")
    await write_audit(
        actor=admin.username or "admin",
        action="LICENSE_REVOKED",
        target_email=doc["email"],
        details=f"License revoked · EA access disabled · license {doc.get('license_id') or '—'}",
    )
    return ActionResponse(ok=True, user=user_row_from_doc(await _load_user(user_id)))


@router.post("/users/{user_id}/suspend", response_model=ActionResponse)
async def suspend_user(user_id: str, admin=Depends(require_admin)) -> ActionResponse:
    doc = await _load_user(user_id)
    if doc.get("license_status") != "ACTIVE":
        raise HTTPException(status_code=409, detail="Only ACTIVE licenses can be suspended.")
    await _sync_license_status(user_id, "SUSPENDED")
    await write_audit(
        actor=admin.username or "admin",
        action="LICENSE_SUSPENDED",
        target_email=doc["email"],
        details=f"License suspended · EA validation will deny · license {doc.get('license_id') or '—'}",
    )
    return ActionResponse(ok=True, user=user_row_from_doc(await _load_user(user_id)))


@router.post("/users/{user_id}/activate", response_model=ActionResponse)
async def activate_user(user_id: str, admin=Depends(require_admin)) -> ActionResponse:
    doc = await _load_user(user_id)
    if doc.get("license_status") not in ("SUSPENDED", "REVOKED"):
        raise HTTPException(status_code=409, detail="Only suspended or revoked licenses can be re-activated.")
    # Re-activating an expired license automatically grants a fresh validity window.
    expiry = doc.get("expiry_date")
    if expiry is not None and expiry.replace(tzinfo=timezone.utc) <= _now():
        months = int(os.environ.get("LICENSE_VALIDITY_MONTHS", "12"))
        expiry = add_months(_now(), months)
        await db.licenses.update_one({"user_id": user_id}, {"$set": {"expiry_date": expiry, "activation_date": _now()}})
        await db.users.update_one({"id": user_id}, {"$set": {"expiry_date": expiry, "activation_date": _now()}})
    await _sync_license_status(user_id, "ACTIVE")
    await write_audit(
        actor=admin.username or "admin",
        action="LICENSE_ACTIVATED",
        target_email=doc["email"],
        details=f"License re-activated · EX5 download enabled · license {doc.get('license_id') or '—'}",
    )
    return ActionResponse(ok=True, user=user_row_from_doc(await _load_user(user_id)))


@router.post("/users/{user_id}/extend", response_model=ActionResponse)
async def extend_user(user_id: str, body: ExtendRequest, admin=Depends(require_admin)) -> ActionResponse:
    doc = await _load_user(user_id)
    current = doc.get("expiry_date")
    if not current:
        raise HTTPException(status_code=409, detail="No license to extend — approve the application first.")
    base = current.replace(tzinfo=timezone.utc)
    if base <= _now():
        base = _now()
    new_expiry = add_months(base, body.months)
    await db.users.update_one({"id": user_id}, {"$set": {"expiry_date": new_expiry}})
    await db.licenses.update_one({"user_id": user_id}, {"$set": {"expiry_date": new_expiry}})
    await write_audit(
        actor=admin.username or "admin",
        action="LICENSE_EXTENDED",
        target_email=doc["email"],
        details=f"Expiry extended by {body.months} months → {new_expiry:%Y-%m-%d}",
    )
    return ActionResponse(ok=True, user=user_row_from_doc(await _load_user(user_id)))


@router.get("/licenses", response_model=list[LicenseRecord])
async def admin_licenses(_admin=Depends(require_admin)) -> list[LicenseRecord]:
    docs = await db.licenses.find({}).sort("created_at", -1).to_list(1000)
    return [license_row_from_doc(doc) for doc in docs]


@router.get("/orders", response_model=list[OrderRow])
async def admin_orders(_admin=Depends(require_admin)) -> list[OrderRow]:
    docs = await db.orders.find({}).sort("created_at", -1).to_list(500)
    return [OrderRow(**doc) for doc in docs]


@router.get("/audit-logs", response_model=list[AuditLogEntry])
async def admin_audit_logs(_admin=Depends(require_admin)) -> list[AuditLogEntry]:
    docs = await db.audit_logs.find({}).sort("created_at", -1).to_list(200)
    return [AuditLogEntry(**doc) for doc in docs]


@router.get("/ea-info", response_model=EaInfo)
async def admin_ea_info(_admin=Depends(require_admin)) -> EaInfo:
    if not EA_FILE.exists():
        raise HTTPException(status_code=503, detail="EA artifact missing from private storage.")
    stat = EA_FILE.stat()
    digest = sha256(EA_FILE.read_bytes()).hexdigest()
    return EaInfo(
        ea_version=os.environ.get("EA_VERSION", "1.2.0"),
        file_size_bytes=stat.st_size,
        sha256=digest,
        updated_at=datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc),
    )
