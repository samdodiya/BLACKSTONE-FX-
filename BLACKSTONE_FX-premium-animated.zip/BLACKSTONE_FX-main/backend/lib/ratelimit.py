"""In-process fixed-window rate limiter for sensitive endpoints (auth, registration,
license checks). Per-IP, per-scope — sufficient for a single-process deployment and
keeps brute-force attempts off the password hashes."""

import time
from collections import defaultdict, deque
from typing import Callable

from fastapi import HTTPException, Request

_hits: dict[str, deque[float]] = defaultdict(deque)


def rate_limit(scope: str, limit: int, window_seconds: int) -> Callable:
    async def dependency(request: Request) -> None:
        client = request.client
        key = f"{scope}:{client.host if client else 'unknown'}"
        now = time.monotonic()
        window = _hits[key]
        while window and window[0] <= now - window_seconds:
            window.popleft()
        if len(window) >= limit:
            raise HTTPException(
                status_code=429,
                detail="Too many requests. Please slow down and try again shortly.",
            )
        window.append(now)

    return dependency
