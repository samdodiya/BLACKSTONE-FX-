"""Append-only audit trail. Every administrative action and security-relevant
event lands here — the admin Control Center reads it immutable."""

import uuid
from datetime import datetime, timezone
from typing import Optional

from lib.db import db


async def write_audit(
    actor: str,
    action: str,
    details: str,
    target_email: Optional[str] = None,
) -> None:
    await db.audit_logs.insert_one(
        {
            "id": str(uuid.uuid4()),
            "actor": actor,
            "action": action,
            "target_email": target_email,
            "details": details,
            "created_at": datetime.now(timezone.utc),
        }
    )
