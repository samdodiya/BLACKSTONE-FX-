"""Serialization helpers: Mongo documents -> response models, with UTC normalisation
and effective-license-status derivation (an ACTIVE license past its expiry reads as
EXPIRED everywhere without a background job having to mutate it)."""

from datetime import datetime, timezone
from typing import Any, Optional

from models.schemas import LicenseRecord, UserRow


def to_aware(dt: datetime) -> datetime:
    """Motor hands back naive UTC datetimes — normalise before comparing or serialising."""
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def effective_license_status(stored: str, expiry_date: Optional[datetime]) -> str:
    if stored == "ACTIVE" and expiry_date is not None:
        if to_aware(expiry_date) <= datetime.now(timezone.utc):
            return "EXPIRED"
    return stored


def user_row_from_doc(doc: dict[str, Any]) -> UserRow:
    expiry = doc.get("expiry_date")
    return UserRow(
        id=doc["id"],
        full_name=doc.get("full_name", ""),
        email=doc.get("email", ""),
        phone=doc.get("phone", ""),
        mt5_account=doc.get("mt5_account", ""),
        broker=doc.get("broker", ""),
        mt5_server=doc.get("mt5_server", ""),
        ib_status=doc.get("ib_status", "PENDING"),
        license_status=effective_license_status(doc.get("license_status", "NONE"), expiry),
        license_id=doc.get("license_id"),
        activation_date=doc.get("activation_date"),
        expiry_date=expiry,
        ea_version=doc.get("ea_version"),
        created_at=doc.get("created_at", datetime.now(timezone.utc)),
    )


def license_row_from_doc(doc: dict[str, Any]) -> LicenseRecord:
    return LicenseRecord(
        id=doc["id"],
        license_id=doc.get("license_id", ""),
        user_id=doc.get("user_id", ""),
        email=doc.get("email", ""),
        mt5_account=doc.get("mt5_account", ""),
        broker=doc.get("broker", ""),
        mt5_server=doc.get("mt5_server", ""),
        status=effective_license_status(doc.get("status", "NONE"), doc.get("expiry_date")),
        activation_date=doc.get("activation_date"),
        expiry_date=doc.get("expiry_date"),
        ea_version=doc.get("ea_version", ""),
        created_at=doc.get("created_at", datetime.now(timezone.utc)),
    )
