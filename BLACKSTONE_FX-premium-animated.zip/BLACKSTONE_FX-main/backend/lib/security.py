"""Authentication primitives: password hashing, JWT session cookies, route guards.

Secrets live in backend/.env (JWT_SECRET) — never in source, never in the frontend.
Sessions are httpOnly cookies; tokens are never returned in JSON bodies.
"""

import os
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

import jwt
from fastapi import Depends, HTTPException, Request, Response
from passlib.context import CryptContext

from lib.db import db
from models.schemas import SessionIdentity

pwd_context = CryptContext(schemes=["pbkdf2_sha256"], pbkdf2_sha256__default_rounds=24_000)

COOKIE_NAME = "bsfx_session"


def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(password: str, password_hash: str) -> bool:
    try:
        return pwd_context.verify(password, password_hash)
    except Exception:
        return False


def _secret() -> str:
    secret = os.environ.get("JWT_SECRET", "")
    if not secret:
        raise RuntimeError("JWT_SECRET is not configured — add it to backend/.env")
    return secret


def _ttl() -> timedelta:
    return timedelta(hours=int(os.environ.get("SESSION_TTL_HOURS", "12")))


def _cookie_secure() -> bool:
    return os.environ.get("COOKIE_SECURE", "false").lower() == "true"


async def create_session(response: Response, sub: str, role: str) -> None:
    """Issue a signed JWT, persist the session server-side, set the httpOnly cookie."""
    sid = str(uuid.uuid4())
    now = datetime.now(timezone.utc)
    ttl = _ttl()
    expires_at = now + ttl
    token = jwt.encode(
        {"sub": sub, "role": role, "sid": sid, "iat": now, "exp": expires_at},
        _secret(),
        algorithm="HS256",
    )
    # Server-side session store: signing out (or an admin purge) revokes the token
    # everywhere, and the sessions TTL index expires stale rows automatically.
    await db.sessions.insert_one(
        {"sid": sid, "user_id": sub, "role": role, "created_at": now, "expires_at": expires_at}
    )
    response.set_cookie(
        COOKIE_NAME,
        token,
        httponly=True,
        samesite="lax",
        secure=_cookie_secure(),
        max_age=int(ttl.total_seconds()),
        path="/",
    )


def decode_token(token: str) -> Optional[dict[str, Any]]:
    try:
        return jwt.decode(token, _secret(), algorithms=["HS256"])
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None


async def destroy_session(request: Request, response: Response) -> None:
    token = request.cookies.get(COOKIE_NAME)
    if token:
        payload = decode_token(token)
        if payload and payload.get("sid"):
            await db.sessions.delete_one({"sid": payload["sid"]})
    response.delete_cookie(COOKIE_NAME, path="/")


async def get_current_identity(request: Request) -> SessionIdentity:
    """Validate the session cookie against the signed token AND the server-side store."""
    token = request.cookies.get(COOKIE_NAME)
    if not token:
        raise HTTPException(status_code=401, detail="Authentication required.")
    payload = decode_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Session expired or invalid. Sign in again.")
    sid = payload.get("sid")
    session = await db.sessions.find_one({"sid": sid})
    if not session:
        raise HTTPException(status_code=401, detail="Session no longer valid. Sign in again.")
    expires_at = session.get("expires_at")
    if expires_at is not None and expires_at.replace(tzinfo=timezone.utc) < datetime.now(timezone.utc):
        raise HTTPException(status_code=401, detail="Session expired. Sign in again.")

    sub = str(payload.get("sub", ""))
    role = str(payload.get("role", ""))
    identity = SessionIdentity(role="admin" if role == "admin" else "customer", id=sub)
    if role == "admin":
        admin = await db.admin_users.find_one({"id": sub})
        if admin:
            identity.username = admin.get("username")
    else:
        user = await db.users.find_one({"id": sub})
        if user:
            identity.full_name = user.get("full_name")
            identity.email = user.get("email")
    return identity


async def require_admin(identity: SessionIdentity = Depends(get_current_identity)) -> SessionIdentity:
    if identity.role != "admin":
        raise HTTPException(status_code=403, detail="Administrator access required.")
    return identity


async def require_customer(identity: SessionIdentity = Depends(get_current_identity)) -> SessionIdentity:
    if identity.role != "customer":
        raise HTTPException(status_code=403, detail="Customer session required.")
    return identity
