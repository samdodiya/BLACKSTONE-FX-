"""Shared Mongo handle — import `client`/`db` from here (server.py, routers, seed.py)."""

import logging
import os
from pathlib import Path

from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import ASCENDING, DESCENDING, IndexModel

load_dotenv(Path(__file__).parent.parent / ".env")

mongo_url = os.environ["MONGO_URL"]
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ["DB_NAME"]]

logger = logging.getLogger(__name__)

# One entry per collection: every field a route filters, sorts, or dedupes on. Applied by ensure_indexes() at startup.
INDEXES: dict[str, list[IndexModel]] = {
    "status_checks": [IndexModel([("timestamp", DESCENDING)], name="timestamp_desc")],
    "users": [
        IndexModel([("id", ASCENDING)], name="id", unique=True),
        IndexModel([("email", ASCENDING)], name="email", unique=True),
        IndexModel([("mt5_account", ASCENDING)], name="mt5_account", unique=True),
        IndexModel([("ib_status", ASCENDING), ("created_at", DESCENDING)], name="ib_status_created"),
    ],
    "admin_users": [
        IndexModel([("id", ASCENDING)], name="id", unique=True),
        IndexModel([("username", ASCENDING)], name="username", unique=True),
    ],
    "sessions": [
        IndexModel([("sid", ASCENDING)], name="sid", unique=True),
        IndexModel([("expires_at", ASCENDING)], name="expires_at_ttl", expireAfterSeconds=0),
    ],
    "licenses": [
        IndexModel([("id", ASCENDING)], name="id", unique=True),
        IndexModel([("license_id", ASCENDING)], name="license_id", unique=True),
        IndexModel([("user_id", ASCENDING)], name="user_id"),
        IndexModel([("mt5_account", ASCENDING)], name="mt5_account"),
    ],
    "orders": [IndexModel([("created_at", DESCENDING)], name="created_desc")],
    "audit_logs": [
        IndexModel([("created_at", DESCENDING)], name="created_desc"),
        IndexModel([("target_email", ASCENDING)], name="target_email"),
    ],
}


async def ensure_indexes() -> None:
    for collection, models in INDEXES.items():
        for model in models:  # one at a time so a bad spec skips only itself
            try:
                await db[collection].create_indexes([model])
            except Exception as exc:  # never block boot on an index; the log line names what to fix
                logger.error("ensure_indexes(%s.%s): %s", collection, model.document["name"], exc)
