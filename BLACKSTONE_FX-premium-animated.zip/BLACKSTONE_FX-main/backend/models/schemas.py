"""Pydantic v2 request/response models for the BLACKSTONE FX licensing platform.

Every model here has a hand-written mirror in frontend/src/lib/types.ts — keep the
two in sync in the same edit (the typed-fetch boundary).
"""

from datetime import datetime
from typing import List, Literal, Optional

from pydantic import BaseModel, EmailStr, Field

IbStatus = Literal["PENDING", "APPROVED", "REJECTED"]
LicenseStatus = Literal["NONE", "PENDING", "ACTIVE", "SUSPENDED", "REVOKED", "EXPIRED"]
Role = Literal["customer", "admin"]


# --- auth -----------------------------------------------------------------
class AdminLoginRequest(BaseModel):
    username: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=1, max_length=128)


class CustomerLoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=128)


class SessionIdentity(BaseModel):
    role: Role
    id: Optional[str] = None
    full_name: Optional[str] = None
    email: Optional[str] = None
    username: Optional[str] = None


# --- registration -----------------------------------------------------------
class RegistrationRequest(BaseModel):
    full_name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    phone: str = Field(min_length=7, max_length=32)
    mt5_account: str = Field(pattern=r"^\d{4,20}$", description="Numeric MT5 account number")
    broker: str = Field(min_length=2, max_length=80)
    mt5_server: str = Field(min_length=2, max_length=120)
    password: str = Field(min_length=8, max_length=128)


class RegisterResponse(BaseModel):
    ok: bool
    status: str
    user_id: str


# --- records ----------------------------------------------------------------
class LicenseRecord(BaseModel):
    id: str
    license_id: str
    user_id: str
    email: str
    mt5_account: str
    broker: str
    mt5_server: str
    status: LicenseStatus
    activation_date: Optional[datetime] = None
    expiry_date: Optional[datetime] = None
    ea_version: str
    created_at: datetime


class UserRow(BaseModel):
    id: str
    full_name: str
    email: str
    phone: str
    mt5_account: str
    broker: str
    mt5_server: str
    ib_status: IbStatus
    license_status: LicenseStatus
    license_id: Optional[str] = None
    activation_date: Optional[datetime] = None
    expiry_date: Optional[datetime] = None
    ea_version: Optional[str] = None
    created_at: datetime


class CustomerDetail(BaseModel):
    user: UserRow
    license: Optional[LicenseRecord] = None


class AuditLogEntry(BaseModel):
    id: str
    actor: str
    action: str
    target_email: Optional[str] = None
    details: str
    created_at: datetime


class OrderRow(BaseModel):
    id: str
    order_id: str
    user_email: Optional[str] = None
    order_type: str
    description: str
    created_at: datetime


class UserDetail(BaseModel):
    user: UserRow
    license: Optional[LicenseRecord] = None
    logs: List[AuditLogEntry] = []


class ActionResponse(BaseModel):
    ok: bool
    user: UserRow


# --- admin ------------------------------------------------------------------
class ExtendRequest(BaseModel):
    months: int = Field(ge=1, le=24)


class PlatformSettings(BaseModel):
    ea_version: str
    license_validity_months: int
    session_ttl_hours: int


class AdminStats(BaseModel):
    total_users: int
    pending_applications: int
    active_licenses: int
    revoked_licenses: int
    total_licenses: int
    orders: int
    settings: PlatformSettings


class EaInfo(BaseModel):
    ea_version: str
    file_size_bytes: int
    sha256: str
    updated_at: datetime


# --- license server (EA-facing) ----------------------------------------------
class LicenseCheckResponse(BaseModel):
    allowed: bool
    reason: str
    license_id: Optional[str] = None
    status: Optional[str] = None
    expiry_date: Optional[datetime] = None


# --- markets -----------------------------------------------------------------
class MarketStatusResponse(BaseModel):
    server_time_utc: str
    market_open: bool
    next_event: str
