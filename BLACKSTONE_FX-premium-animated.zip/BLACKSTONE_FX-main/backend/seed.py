"""Idempotent seed for the BLACKSTONE FX licensing platform.

Creates the administrator account (credentials from backend/.env), plus demo
customers in every license state so the Control Center and Portal are testable
immediately. Safe to run repeatedly — records are upserted, never duplicated.

Run:  cd /app/backend && python seed.py
"""

import asyncio
import os
import uuid
from datetime import datetime, timedelta, timezone

from lib.audit import write_audit
from lib.db import db, ensure_indexes
from lib.dates import add_months
from lib.security import hash_password

DEMO_PASSWORD = "Demo@12345"
EA_VERSION = os.environ.get("EA_VERSION", "1.2.0")

CUSTOMERS = [
    {
        "full_name": "Demo Trader",
        "email": "demo@blackstonefx.com",
        "phone": "+971500000001",
        "mt5_account": "5100001",
        "broker": "IC Markets",
        "mt5_server": "ICMarketsSC-MT5",
        "state": "ACTIVE",
    },
    {
        "full_name": "Aisha Rahman",
        "email": "pending@blackstonefx.com",
        "phone": "+971500000002",
        "mt5_account": "5100002",
        "broker": "Exness",
        "mt5_server": "Exness-MT5Real8",
        "state": "PENDING",
    },
    {
        "full_name": "Victor Hale",
        "email": "revoked@blackstonefx.com",
        "phone": "+441500000003",
        "mt5_account": "5100003",
        "broker": "Pepperstone",
        "mt5_server": "Pepperstone-Live07",
        "state": "REVOKED",
    },
    {
        "full_name": "Lena Fischer",
        "email": "suspended@blackstonefx.com",
        "phone": "+491500000004",
        "mt5_account": "5100004",
        "broker": "FXTM",
        "mt5_server": "FXTM-Real28",
        "state": "SUSPENDED",
    },
]


async def seed_admin() -> None:
    username = os.environ.get("ADMIN_USERNAME", "admin").lower()
    password = os.environ.get("ADMIN_PASSWORD", "Bstone#Admin2026")
    now = datetime.now(timezone.utc)
    doc = await db.admin_users.find_one({"username": username})
    if doc is None:
        await db.admin_users.insert_one({
            "id": str(uuid.uuid4()),
            "username": username,
            "password_hash": hash_password(password),
            "created_at": now,
        })
        print(f"[seed] admin account created: {username}")
    else:
        await db.admin_users.update_one(
            {"username": username}, {"$set": {"password_hash": hash_password(password)}}
        )
        print(f"[seed] admin password refreshed: {username}")


async def seed_customer(spec: dict) -> None:
    now = datetime.now(timezone.utc)
    doc = await db.users.find_one({"email": spec["email"]})
    if doc is None:
        doc = {
            "id": str(uuid.uuid4()),
            "full_name": spec["full_name"],
            "email": spec["email"],
            "phone": spec["phone"],
            "mt5_account": spec["mt5_account"],
            "broker": spec["broker"],
            "mt5_server": spec["mt5_server"],
            "password_hash": hash_password(DEMO_PASSWORD),
            "ib_status": "PENDING",
            "license_status": "PENDING",
            "license_id": None,
            "activation_date": None,
            "expiry_date": None,
            "ea_version": None,
            "created_at": now,
        }
        await db.users.insert_one(doc)
        await db.orders.insert_one({
            "id": str(uuid.uuid4()),
            "order_id": "ORD-" + uuid.uuid4().hex[:8].upper(),
            "user_id": doc["id"],
            "user_email": spec["email"],
            "order_type": "IB_REGISTRATION",
            "description": "IB application submitted via referral TRI3lX2K",
            "created_at": now,
        })
        await write_audit(
            actor=spec["email"],
            action="REGISTRATION_SUBMITTED",
            target_email=spec["email"],
            details=f"Seed application · MT5 {spec['mt5_account']} @ {spec['broker']}",
        )
        print(f"[seed] customer created: {spec['email']}")
    else:
        # keep the demo password in sync with this script
        await db.users.update_one({"id": doc["id"]}, {"$set": {"password_hash": hash_password(DEMO_PASSWORD)}})

    state = spec["state"]
    if state == "PENDING":
        return

    license_id = doc.get("license_id") or "BSFX-" + "-".join(uuid.uuid4().hex[:4].upper() for _ in range(3))
    activation = now - timedelta(days=45)
    expiry = add_months(now, 12)
    await db.users.update_one(
        {"id": doc["id"]},
        {"$set": {
            "ib_status": "APPROVED",
            "license_status": state,
            "license_id": license_id,
            "activation_date": activation,
            "expiry_date": expiry,
            "ea_version": EA_VERSION,
        }},
    )
    await db.licenses.update_one(
        {"user_id": doc["id"]},
        {"$set": {
            "license_id": license_id,
            "email": spec["email"],
            "mt5_account": spec["mt5_account"],
            "broker": spec["broker"],
            "mt5_server": spec["mt5_server"],
            "status": state,
            "activation_date": activation,
            "expiry_date": expiry,
            "ea_version": EA_VERSION,
        }, "$setOnInsert": {"id": str(uuid.uuid4()), "user_id": doc["id"], "created_at": now}},
        upsert=True,
    )
    if not await db.orders.find_one({"user_id": doc["id"], "order_type": "EA_LICENSE"}):
        await db.orders.insert_one({
            "id": str(uuid.uuid4()),
            "order_id": "ORD-" + uuid.uuid4().hex[:8].upper(),
            "user_id": doc["id"],
            "user_email": spec["email"],
            "order_type": "EA_LICENSE",
            "description": f"License {license_id} activated for MT5 {spec['mt5_account']} ({spec['broker']})",
            "created_at": now,
        })
        await write_audit(
            actor="admin",
            action="APPLICATION_APPROVED",
            target_email=spec["email"],
            details=f"Seed approval · license {license_id} → {state}",
        )
    print(f"[seed] license ensured: {spec['email']} → {state}")


async def main() -> None:
    await ensure_indexes()
    await seed_admin()
    for spec in CUSTOMERS:
        await seed_customer(spec)
    print("[seed] done.")


if __name__ == "__main__":
    asyncio.run(main())
