# BLACKSTONE FX — Platform Spec

Premium automated-trading technology platform: a marketing site plus a working
account-bound licensing system for an MT5 Expert Advisor (EA).

Stack: FastAPI + MongoDB (motor) backend on `/api`, Vite + React 19 + TypeScript
frontend (Tailwind v4, shadcn/base-ui, TanStack Query, motion).

Public URL: https://fx-ecosystem-dev.preview.emergentagent.com

## What the app does

A visitor explores the EA, applies through the official IB referral, and submits
their MT5 account/broker/server. The application sits at PENDING until an
administrator approves it. On approval a license is activated and bound to that
exact MT5 account + broker + server; only then does the compiled EX5 become
downloadable. The EA validates against the license server on every run cycle, so
a copied EX5 cannot operate on an unapproved account.

## Routes (frontend)

| Path | Page | Access |
|---|---|---|
| `/` | Home — hero, feature strip, 6 EA feature cards, flow, CTA | public |
| `/markets` | Live Markets — TradingView terminal, 5 symbols, 6 timeframes | public |
| `/ea-intelligence` | EA Intelligence — pipeline + 8 system pillars | public |
| `/access` | Access — 8-step IB roadmap + registration form | public |
| `/login` | Bi-modal auth (Trader Portal / Terminal Admin) | public |
| `/portal` | Customer Portal — Overview, My License, EA Download, Account, Support | customer session |
| `/admin` | Control Center — Dashboard, Applications, Customers, Licenses, Orders, EA Access, Audit Logs, Settings | admin session |
| `/terms`, `/privacy`, `/risk-disclosure` | Legal | public |
| `*` | 404 | public |

## Data model (MongoDB)

- **users** — `id`(uuid), full_name, email(unique), phone, mt5_account(unique),
  broker, mt5_server, password_hash, `ib_status` (PENDING/APPROVED/REJECTED),
  `license_status`, license_id, activation_date, expiry_date, ea_version, created_at
- **licenses** — `id`, `license_id`(unique, `BSFX-XXXX-XXXX-XXXX`), user_id, email,
  mt5_account, broker, mt5_server, status, activation_date, expiry_date, ea_version
- **admin_users** — id, username(unique), password_hash
- **sessions** — sid(unique), user_id, role, expires_at (TTL index)
- **orders** — order_id, user_email, order_type (IB_REGISTRATION | EA_LICENSE), description
- **audit_logs** — actor, action, target_email, details, created_at

License status values: `NONE | PENDING | ACTIVE | SUSPENDED | REVOKED | EXPIRED`.
An ACTIVE license past its expiry is derived as EXPIRED on read
(`lib/licensing.effective_license_status`) — no cron needed.

## API (all on `api_router`, prefix `/api`)

Auth: `POST /auth/admin/login`, `POST /auth/customer/login`, `POST /auth/logout`, `GET /auth/me`
Public: `POST /register`, `GET /market/status`
Customer: `GET /customer/me`
License server: `GET /license/check?mt5_account=&broker=&mt5_server=`, `GET /ea/download`
Admin: `GET /admin/stats`, `GET /admin/users`, `GET /admin/users/{id}`,
`POST /admin/users/{id}/{approve|reject|revoke|suspend|activate|extend}`,
`GET /admin/licenses`, `GET /admin/orders`, `GET /admin/audit-logs`, `GET /admin/ea-info`

`/license/check` reasons: `LICENSE_ACTIVE` (allowed) · `LICENSE_NOT_FOUND` ·
`BINDING_MISMATCH` · `IB_NOT_APPROVED` · `LICENSE_{PENDING|SUSPENDED|REVOKED|EXPIRED}`.
Broker/server matching is case-insensitive and whitespace-trimmed.

## Auth & security

- Sessions: signed JWT in an **httpOnly** cookie (`bsfx_session`, SameSite=Lax) **plus**
  a server-side `sessions` row — logout deletes the row, so the token dies immediately.
  Tokens are never returned in JSON and never touched by frontend code.
- Passwords: PBKDF2-SHA256 via passlib.
- Rate limits (per IP, fixed window): admin login 10/60s, customer login 10/60s,
  registration 8/600s, license check 90/60s.
- Authorization is server-side per request (`require_admin` / `require_customer`);
  a customer session hitting an admin route gets 403.
- Secrets live only in `backend/.env` (`JWT_SECRET`, `ADMIN_PASSWORD`, …), read via `os.environ`.

## EA file security

- `backend/private/Blackstone_EA.ex5` — compiled artifact, served ONLY through
  `GET /api/ea/download` after the license gate passes.
- `backend/private/Blackstone_EA_SOURCE.mq5` — proprietary source, **not attached to any
  route** and not in the frontend public directory. Unreachable over HTTP.
- Customer download requires: `ib_status == APPROVED` AND effective license status
  `ACTIVE` AND license binding matching the user's own account/broker/server.
  Denials are audit-logged as `EA_DOWNLOAD_DENIED`.
- The EX5 in this repo is a **PLACEHOLDER BINARY**, not a real MT5 expert — replace it
  with the real compiled artifact at the same path.

## Known deviations / notes

- TradingView uses the free public Advanced Chart widget (display-only, no API key).
  Symbols map to the OANDA feed; US100 → `OANDA:NAS100USD`.
- Market open/closed is an indicative FX/metals session calculation (server-side UTC),
  not a broker calendar feed.
- The ticker ribbon shows instrument identities only — no fabricated prices anywhere.
- No profit or performance claims appear in any copy; risk disclosure is in the footer,
  the home CTA, EA Intelligence and a dedicated page.
